/**
 * Created by biddwan on 25 May 2018.
 */
const config = require('../config');
const axios = require('axios');
controllerInstance = axios.create({
    baseURL: config.urls.CONTROLLER_SERVICE
});
const facebookSignature = '"6cab9a2aada111452fa2db8ba663fb6e29208d76e6b27b8ec75e97482bf70d2f"';
const sendResponse = (bot, sender, source, data, mapping, responseType) => {
    if (source === 'facebook') {
        return controllerInstance.post('/facebook/send', {
            data: data,
            signature: facebookSignature,
            sender: sender,
            bot: bot,
            messageType: 'BOT',
            mapping: mapping
        })
    } else if (source === 'botframework' || source === 'skype') {
        return controllerInstance.post(`/botframework/send`, {
            data: data,
            sender: sender,
            bot: bot,
            messageType: 'BOT',
            mapping: mapping
        })
    } else if (source === 'yellowmessenger') {
        return controllerInstance.post('/yellowmessenger/send', {
            data: data,
            sender: sender,
            bot: bot,
            messageType: 'BOT'
        })
    } else if (source === 'sms') {
        return controllerInstance.post('/sms/send', {
            data: data,
            sender: sender,
            bot: bot,
            messageType: 'BOT',
            mapping: mapping
        })
    }
};

const sendTyping = (bot, sender) => {
    return controllerInstance.post('/yellowmessenger/send-typing', {
        sender: sender,
        bot: bot
    })
};

module.exports = {
    sendResponse,
    sendTyping
};
