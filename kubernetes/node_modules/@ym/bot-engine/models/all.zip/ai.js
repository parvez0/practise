const
    request = require('request'),
    bpConfig = require('../config');
    Q = require('q');
    _ = require('lodash');
request.defaults({
    timeout: 1000,
    pool: {maxSockets: 5000},
});


let AI = function (bot) {
    this.predict = function (text, context, entityThreshold) {
        let body = {
            text: text
        };

        if(context){
            body["context"] = context;
        }
        if(entityThreshold){
            body["entity-threshold"] = entityThreshold;
        }

        return new Promise(function (resolve, reject) {
            request.post({
                url: `${bpConfig.urls.ML}/prediction-internal?bot=`+bot,
                json:  body
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };

    this.predictMultiple = function (text, bots) {
        return new Promise(function (resolve) {
            Q.allSettled(_.map(bots, function (bot) {
                return new Promise(function (resolve, reject) {
                    request.post({
                        url: `${bpConfig.urls.ML}/prediction-internal?bot=${bot}`,
                        json: {
                            text: text,
                            bot: bot
                        }
                    }, (err, response, resp) => {
                        if (err) {
                            console.log('Timed out for predict-multiple bot : ' + bot + JSON.stringify(err));
                            reject(err);
                        } else {
                            resolve(resp);
                        }
                    });
                });
            })).then(function (results) {
                resolve(results);
            });
        });
    };

    this.predictHack = function (text, otherBot) {
        return new Promise(function (resolve, reject) {
            request.get({
                url: `${bpConfig.urls.ML}/prediction-internal`,
                qs: {
                    text: encodeURIComponent(text),
                    bot: otherBot
                },
                json: true
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };


    this.nlp = function (text) {
        return new Promise(function (resolve, reject) {
            request.post({
                url: `${bpConfig.urls.ML}/nlp-internal`,
                qs: {
                    bot: bot
                },
                json: {
                    text: text
                }
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };

    this.addTraining = function (text, intent) {
        return new Promise(function (resolve, reject) {
            request.post({
                url: `${bpConfig.urls.ML}/add-training-internal`,
                qs: {
                    bot: bot
                },
                json: {
                    text: text,
                    intent: intent
                }
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };

    this.addUserTraining = function (text, intent) {
        return new Promise(function (resolve, reject) {
            request.post({
                url: `${bpConfig.urls.ML}/add-user-training-internal`,
                qs: {
                    bot: bot
                },
                json: {
                    text: text,
                    intent: intent
                }
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };

    this.trainIntents = function () {
        return new Promise(function (resolve, reject) {
            request.get({
                url: `${bpConfig.urls.ML}/train-intents-internal`,
                qs: {
                    bot: bot
                },
                json: true
            }, (err, response, resp) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(resp);
                }
            });
        });
    };

    this.addToUnIdentifiedList = function (text, userId, source) {
        return new Promise(function (resolve, reject) {
            let options = {
                method: 'POST',
                url: `${bpConfig.urls.ML}/add-unidentified-internal`,
                qs: {
                    bot: bot
                },
                headers: {
                    'cache-control': 'no-cache',
                    'content-type': 'application/json'
                },
                body: {
                    utterance: text,
                    user_id: userId,
                    source: source
                },
                json: true
            };

            request(options, function (error, response, body) {
                if (error) {
                    reject(error);
                } else {
                    resolve(body);
                }
            });
        });
    };
};

module.exports = {
    AI: AI
};
