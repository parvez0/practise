'use strict';
const
    rpcClient = require('./rpcClient');

let facebook = {
    sendMessageBeta: function(sender, data, from, callback) {
        rpcClient.call("facebook/sendMessageBeta", {sender: sender, data: data, from: from}).then(callback);
    }
};

let ym = {
    sendMessage: function(sender, data, from, callback) {
        rpcClient.call("ym/sendMessage", {to: sender, data: data, from: from}).then(callback);
    }
};

let botframework = {
    sendMessage : function(sender, data, from, callback) {
        rpcClient.call("botframework/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let sms =  {
    sendMessage: function(sender, data, from, callback) {
        rpcClient.call("sms/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let line = {
    sendMessage: function(sender, data, from, callback) {
        rpcClient.call("line/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let alexa = {
    sendMessage : function(sender, data, from, callback) {
        rpcClient.call("alexa/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let googleAssistant = {
    sendMessage : function(sender, data, from, callback) {
        rpcClient.call("googleAssistant/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let twilio = {
    sendMessage : function(sender, data, from, callback) {
        rpcClient.call("twilio/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

let kookoo = {
    sendMessage : function(sender, data, from, callback) {
        rpcClient.call("kookoo/sendMessage", {sender: sender, data: data, from: from}).then(callback);
    }
};

module.exports = {
    facebook,
    ym,
    botframework,
    sms,
    line,
    alexa,
    googleAssistant,
    twilio,
    kookoo
};
