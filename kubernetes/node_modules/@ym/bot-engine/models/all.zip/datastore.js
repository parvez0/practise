/**
 * Created by sachin on 27 Apr 2018.
 */
'use strict';
const config = require('../config');
const axios = require('axios');
const dataURL = config.urls.DATA_SERVICE;
const axiosInstance = axios.create({
    baseURL: dataURL
});

const axiosDataWrapper = (data, serviceName) => {
    return axiosInstance({
        method: 'post',
        url: `/datastore/${serviceName}-internal`,
        data
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    });
};

let DataStore = function (bot) {

    this.search = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'search');
    };

    this.find = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'find');
    };

    this.count = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'count');
    };

    this.aggregate = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'aggregate');
    };

    this.insert = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'insert');
    };

    this.update = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'update');
    };

    this.updateMany = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'updateMany');
    };

    this["delete"] = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'delete');
    };

    this["get"] = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'get');
    };

    this.getForm = function (data) {
        data.username = bot;
        return axiosDataWrapper(data,'getForm');
    };
};

module.exports = {
    DataStore,
    datastore: DataStore
};
