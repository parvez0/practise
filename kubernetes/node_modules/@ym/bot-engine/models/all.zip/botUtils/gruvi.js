/**
 * Created by sachin on 27 Apr 2018.
 */
const request = require('request');
const GRUVI_API_KEY = 'c87bfbb769147aa04b3390a81dd07e5d';
let showTimesApi = (endpoint, id, params) => {
    return new Promise((resolve, reject) => {
        let options = {
            url: `http://api.internationalshowtimes.com/v4/${endpoint}/${id}`,
            json: true,
            headers: {
                'X-Api-Key': GRUVI_API_KEY,
                'Cache-Control': 'no-cache'
            }
        };
        if (params) {
            options.qs = params;
        }
        request.get(options, (err, response, data) => {
            if (err) {
                reject(err);
            } else {
                if (data.error) {
                    reject(data.error);
                } else {
                    resolve(data);
                }
            }
        });
    });
};

module.exports = {
    showTimesApi,
};