/**
 * Created by sachin on 27 Apr 2018.
 */
const request = require('request');
let getUser =  (userId) => {
    return new Promise(function (resolve, reject) {
        let url = `https://api8.successfactors.com/odata/v2/User('${userId}')?$select=payGrade,userId,division,location,firstName,lastName,email,username,addressLine1,department,custom07,division,location,gender,status,city,state,zipCode,custom01,jobCode,manager/userId,manager/username,incumbentOfPositionNav/payGradeNav/name&$expand=manager,empInfo/jobInfoNav,empInfo,incumbentOfPositionNav/payGradeNav&$format=json`;
        let options = {
            method: 'GET',
            url: url,
            headers: {
                'cache-control': 'no-cache',
                'content-type': 'application/json',
                authorization: "Basic " + (new Buffer(mapping.auth.successFactors.username + ":" + mapping.auth.successFactors.password).toString('base64'))
            },
            json: true
        };

        request(options, function (error, response, dataBody) {
            if (error || dataBody.error || !dataBody.d) {
                reject(dataBody && dataBody.error ? dataBody.error.message : "error");
            } else {
                resolve(dataBody.d);
            }
        });
    });
}
module.exports = {
    getUser
};