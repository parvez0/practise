'use strict';
const config = require('../config');
const axios = require('axios');
const {set} = require('./memory');
const axiosInstance = axios.create({
    baseURL: config.urls.DATA_SERVICE
});

const sessionExpiry = 10;
const metrics = require('metrics-druid');

const axiosVaultWrapper = (data, serviceName) => {
    return axiosInstance({
        method: 'post',
        url: `/internal/vault/${serviceName}`,
        data
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    });
};

module.exports = {
    getCode: function (botId) {
        return axios.get(config.urls.DATA_SERVICE + '/internal/vault/code', {
            params: {
                bot: botId
            }
        })
    },
    getProfile: function (uid, bot, source, botMapping) {
        return axiosVaultWrapper({
            uid,
            bot,
            source,
            botMapping
        }, 'profile');
    },
    updateFirstTimeUser: function (sender, bot, source) {
        return axiosVaultWrapper({
            sender,
            bot,
            source
        }, 'updateFirstTimeUser');
    },
    saveOrUpdateProfile: function (sender, bot, source, profile) {
        return axiosVaultWrapper({
            sender,
            bot,
            source,
            profile
        }, 'saveOrUpdateProfile');
    },
    updateVaultLogName: function (sender, bot, source, newName) {
        return axiosVaultWrapper({
            sender,
            bot,
            source,
            newName
        }, 'updateVaultLogName');
    },
    getFunction: function (funcName, bot) {
        return axiosInstance.get(`/functions/internal/code/${funcName}?bot=${bot}`).then((response) => {
            return response.data.data.code;
        })
    },
    updateMessage: function (messageId, messageObj) {
        return axiosInstance.post(`/internal/message/update/${messageId}`, messageObj).then((response) => {
            return response.data;
        })
    },
    createMessage: function (uid, source, botId, sessionId, message, sessionObject, receivedMessageTime, questionId, orchestratorBotId) {
        //druid offers regex so we can increment v3 and combine search when we need it
        const messageType = 'BOT';
        sessionObject.time = new Date().toISOString();
        const sessionKey = botId + uid + '$botfather:session';
        set(sessionKey, JSON.stringify(sessionObject), sessionExpiry * 60);
        const timeDelta = (new Date().getTime() - new Date(receivedMessageTime).getTime()) / 1000;
        metrics.increment("events.messages.count", {
            uid,
            source,
            user: botId,
            sessionId,
            message,
            messageType,
        }, timeDelta);

        return axiosInstance.post(`/internal/message/create/${botId}`, {
            uid,
            source,
            sessionId,
            message,
            messageType,
            questionId,
            orchestratorBotId
        }).then((response) => {
            return response.data;
        })
    },
    getFunctionsList: function (botId) {
        return axiosInstance.get(`functions/internal/list?bot=${botId}`).then((response) => {
            return response.data.data;
        })
    }

};
