'use strict';
const
    bpConfig = require('../config'),
    config = require('../config'),
    uuidV1 = require('uuid/v1'),
    request = require('request').defaults({pool: {maxSockets: 10}}),
    metrics = require('metrics-druid'),
    mailer = require('./emailer'),
    _ = require('lodash'),
    crypto = require('crypto'),
    https = require("https"),
    mustache = require('mustache'),
    {DataStore} = require('./datastore'),
    {Memory, getContextOfOtherUser} = require('./memory'),
    actionLib = require('./action-lib'),
    emailSender = require('./emailSender'),
    rabbit = require('./rabbit'),
    agents = require('./agents'),
    {AI} = require('./ai'),
    vault = require('./vault'),
    facebook = require('./messages').facebook,
    ym = require('./messages').ym,
    botframework = require('./messages').botframework,
    sms = require('./messages').sms,
    line = require('./messages').line,
    Q = require('q'),
    cheerio = require('cheerio'),
    imageRequest = require('request').defaults({encoding: null}),
    wordToNumber = require('./words-to-numbers'),
    googleAssistant = require('./messages').googleAssistant,
    alexa = require('./messages').alexa,
    kookoo = require('./messages').kookoo,
    twilio = require('./messages').twilio,
    stringMatch = require('../models/stringMatch'),
    numeral = require('numeral'),
    geolib = require('geolib'),
    time = require('time'),
    xml2json = require('xml2json'),
    sanitizeHtml = require('sanitize-html'),
    phoneParse = require('phone-parse'),
    phonetics = require('./utils/phonetics'),
    gruvi = require('./botUtils/gruvi'),
    geoUtil = require('./utils/geoUtils'),
    {machineComprehension} = require('./utils/ml'),
    {sendResponse, sendTyping} = require('./sendData'),
    {createSasUrl} = require('./upload'),
    axios = require('axios'),
    soap = require('soap'),
    {encrypt, decrypt} = require('./utils/encryption'),
    agentsInstance = axios.create({
        baseURL: config.urls.AGENTS_SERVICE,
        timeout: 1000,
    });

let botHelper = require('./utils/bot');

request.request = request;

//Overriding Promise
global.Promise = require("bluebird");
Promise.config({
    longStackTraces: true
});

const translateClient = require('./utils/translateClient');
const {Analytics} = require('./analytics/analytics');
let {Orchestrator} = require('./orchestrator/orchestrator');
let {Logger} = require('./logger/logger');

const knowledge = require('./knowledge');
let ContextProcessor = function (app, botMapping) {
    let self = this;
    let context;
    let loadContext = function () {
        return new Promise(function (resolve, reject) {
            app.memory.get("context").then(function (contextString) {
                context = JSON.parse(contextString);
                resolve();
            }, function () {
                context = {};
                resolve();
            });
        });
    };


    let nextStep = function (journeyDetails) {
        let skipList = [];
        let result;
        try {
            if (!context.steps) {
                context.steps = {};
            }

            let dataProps = {source: app.source, options: app.options, profile: app.profile, steps: context.steps};

            for (let i in journeyDetails.stepConditions) {
                if (journeyDetails.stepConditions[i].type === "channels") {
                    if (journeyDetails.stepConditions[i].channels.indexOf(app.source) !== -1) {
                        skipList.push(journeyDetails.stepConditions[i].step)
                    }
                }
                else if (journeyDetails.stepConditions[i].type === "steps") {
                    result = isNaN(context.steps[journeyDetails.stepConditions[i].rule.step]) && isNaN(journeyDetails.stepConditions[i].rule.value) ? eval("context.steps[journeyDetails.stepConditions[i].rule.step]" + journeyDetails.stepConditions[i].rule.operator + "journeyDetails.stepConditions[i].rule.value") : eval(Number(context.steps[journeyDetails.stepConditions[i].rule.step]) + journeyDetails.stepConditions[i].rule.operator + Number(journeyDetails.stepConditions[i].rule.value));
                    if (result) {
                        skipList.push(journeyDetails.stepConditions[i].step)
                    }
                }
            }


        } catch (e) {
            app.log(e);
        }

        let i = 0;
        for (; i < journeyDetails.steps.length; i++) {
            if (context.steps[journeyDetails.steps[i].slug] === undefined && skipList.indexOf(journeyDetails.steps[i].slug) === -1) {
                break;
            }
        }

        context.complete = false;

        if (i >= journeyDetails.steps.length) {
            context.complete = true;
            delete context.paramExpected;
            delete context.question;
            delete context.options;
            delete context.questionOptions;
            delete context.questionFunction;
            delete context.stepId;
        } else {
            context.paramExpected = journeyDetails.steps[i].slug;
            context.questionOptions = {};

            // if (action.params[i].hideInput) {
            //     if (!context.questionOptions) {
            //         context.questionOptions = {};
            //     }
            //     context.questionOptions.hideInput = true;
            // } else {
            //     delete context.questionOptions;
            // }

            if (journeyDetails.steps[i].slug.options) {
                context.options = generateOptions(app.options.targetLanguage && app.options.targetLanguage !== "en" && action.params[i].locale && action.params[i].locale[app.options.targetLanguage] ? action.params[i].locale[app.options.targetLanguage].options : action.params[i].options);
            } else {
                delete context.options;
            }
        }
    };

    //a function to get randomize messages
    let randomizeMessages = function (array) {
        let randomNumber = Math.floor(Math.random() * array.length);
        if (randomNumber === array.length) {
            return array[randomNumber - 1]
        }
        else {
            return array[randomNumber]
        }
    };

    // a function to select the message type
    let selectMessageType = function (response, dataProps) {
        let msgSent;
        let showResponse = true;
        let result;
        // looping through all the filters
        for (let i in response.filters) {
            if (response.filters[i].type === "channels" && response.filters[i].channels && response.filters[i].channels.length > 0) {
                if (response.filters[i].channels.indexOf(app.source) === -1) {
                    showResponse = false;
                    break
                }
            }
            else if (response.filters[i].type === "steps" && context.steps[response.filters[i].step]) {
                result = isNaN(context.steps[response.filters[i].step]) && isNaN(response.filters[i].value) ? eval("context.steps[response.filters[i].step]" + response.filters[i].operator + "response.filters[i].value") : eval(Number(context.steps[response.filters[i].step]) + response.filters[i].operator + Number(response.filters[i].value));
                if (!result) {
                    showResponse = false;
                    break;
                }
            }
            else if (response.filters[i].type === "custom") {
                result = isNaN(app.mustache.render(response.filters[i].expression, dataProps)) && isNaN(app.mustache.render(response.filters[i].value, dataProps)) ? eval("app.mustache.render(response.filters[i].expression,dataProps).toString()" + response.filters[i].operator + "mustache.render(response.filters[i].value,dataProps).toString()") : eval(Number(app.mustache.render(response.filters[i].expression, dataProps)) + response.filters[i].operator + Number(app.mustache.render(response.filters[i].value, dataProps)));
                if (!result) {
                    showResponse = false;
                    break;
                }
            }
        }
        if (showResponse) {
            switch (response.type) {
                case "Email":
                    let to = response.to.split(',');
                    let subject = response.subject;
                    let body = response.body;
                    let html = response.html;
                    msgSent = new Promise(function (resolve, reject) {
                        mailer.sendEmail(to, subject, body, {}, '', html);
                        resolve();
                    });
                    break;
                case "SMS":
                    break;
                case "Video":
                    msgSent = app.sendVideo({url: response.url});
                    break;
                case "Clear":
                    msgSent = new Promise(function (resolve, reject) {
                        self.clearContext();
                        resolve();
                    });
                    break;
                case "quickReplies":
                    // Fill the template
                    response.quickReplies.title = app.mustache.render(randomizeMessages(response.quickReplies.title), dataProps);
                    msgSent = app.sendQuickReplies(response.quickReplies);
                    break;
                case "image":
                    msgSent = app.sendImage(response.image);
                    break;
                case "cards":
                    msgSent = app.sendCards(response.cards);
                    break;
                case "WelcomeMessage":
                    msgSent = app.sendWelcomeMessage(response.welcomeMessageText ? app.mustache.render(response.welcomeMessageText, dataProps) : undefined);
                    break;
                case "text":
                    msgSent = app.sendTextMessage(app.mustache.render(randomizeMessages(response.messages), dataProps));
                    break;
                case "TriggerIntent":
                    app.clearContext();
                    app.data.message = app.mustache.render(response.trigger, dataProps);
                    app.start();
                    return;

                case "Event":
                    let event = response.event;
                    if (event.data) {
                        for (let key in event.data) {
                            if (event.data.hasOwnProperty(key)) {
                                event.data[key] = app.mustache.render(event.data[key], dataProps)
                            }
                        }
                    }
                    msgSent = app.sendEvent(event);
                    break;
                case "SupportTicket":
                    let ticket = response.ticket;
                    msgSent = app.createTicket(app.mustache.render(ticket.issue, dataProps), app.profile, ticket.route);
                    break;
                case "func":
                    msgSent = new Promise((resolve) => {
                        let result = app.functionWrapper(response.func, response.args);
                        if (result instanceof Promise) {
                            result.then(() => {
                                resolve();
                            })
                        }
                        else {
                            resolve();
                        }
                    });

                    break;
                case "Database":
                    msgSent = new Promise(function (resolve, reject) {
                        let query = {};
                        for (let key in response.database.query) {
                            if (response.database.query.hasOwnProperty(key)) {
                                query[key] = app.mustache.render(response.database.query[key], dataProps);
                            }
                        }

                        app.datastore.find({
                            table: response.database.collection,
                            query: query
                        }).then(function (results) {
                            if (!results || results.length === 0) {
                                app.sendTextMessage(app.mustache.render(response.database.emptyMessage || "No results found", dataProps))
                                    .then(function () {
                                        resolve();
                                    });
                            } else {
                                let foundMessageSent = Promise.resolve();
                                if (response.database.foundMessage) {
                                    foundMessageSent = app.sendTextMessage(app.mustache.render(response.database.foundMessage, results[0]));
                                }
                                foundMessageSent.then(function () {
                                    let msgSent = undefined;
                                    switch (response.database.type) {
                                        case "Message":
                                            msgSent = app.sendTextMessage(app.mustache.render(response.database.message, results[0]));
                                            break;
                                        case "QuickReplies":
                                            msgSent = app.sendQuickReplies({
                                                title: app.mustache.render(response.database.quickReplies.title, results[0]),
                                                options: _.map(response.database.quickReplies, function (option) {
                                                    for (let key in option) {
                                                        if (option.hasOwnProperty(key)) {
                                                            option[key] = app.mustache.render(option[key], results[0]);
                                                        }
                                                    }
                                                })
                                            });
                                            break;
                                        case "Cards":
                                            msgSent = app.sendCards(_.map(results, function (result) {
                                                return {
                                                    image: result[response.database.card.image],
                                                    title: result[response.database.card.title],
                                                    text: result[response.database.card.text],
                                                    actions: _.map(response.database.card.actions, function (action) {
                                                        for (let key in action) {
                                                            if (action.hasOwnProperty(key)) {
                                                                action[key] = app.mustache.render(action[key], results[0]);
                                                            }
                                                        }
                                                        return action;
                                                    })
                                                };
                                            }));
                                            break;
                                        default:
                                            msgSent = app.sendTextMessage("Found results");
                                    }
                                });
                            }
                        });
                    });
                    break;
                default:
                    msgSent = Promise.resolve();
                    break;
            }
            return msgSent;
        }
        else {
            return Promise.resolve();
        }

    };

    let completeJourney = function (prediction, journeyDetails) {
        return new Promise(function (resolve, reject) {
            app.analytics.incrementInternal("journey-completed", _.assign({message: app.data.message | ""}, {
                name: context.journeyName,
                steps: context.steps
            }));
            app.xmppObj = _.assign(app.xmppObj, {
                journeyId: journeyDetails._id,
                journeyName: journeyDetails.name,
                journeySlug: journeyDetails.slug
            });
            if (botMapping && botMapping.skin && botMapping.skin.defaultAutoComplete) {
                app.xmppObj.defaultAutoComplete = botMapping.skin.defaultAutoComplete;
            }
            if (journeyDetails.slug === 'default') {
                // if default step doesnt have answer for orchestrator then app.ask is called again
                if (app.referrer && !app.orchestratorStarted) {
                    if (app.options.enableSuggestion) {
                        let journeys = [];
                        // if confidence of intents in prediction is greater than suggestionConfidence then did you mean is asked
                        Object.keys(app.prediction.intents).forEach((key) => {
                            if (app.prediction.intents[key] > app.options.suggestionConfidence) {
                                journeys.push(key);
                            }
                        });
                        if (journeys.length > 0) {
                            app.getMultipleJourneysBySlug(journeys).then((allJourneys) => {
                                let options = [];
                                let suggestionOptions = [];
                                allJourneys.forEach((journey) => {
                                    if (journey.description){
                                        options.push({
                                            title: journey.description.replace(/\b\w/g, l => l.toUpperCase()).replace(/_/gi, " "),
                                            text: journey.description.replace(/_/gi, " ").toLowerCase()
                                        });
                                        suggestionOptions.push({
                                            slug: journey.slug,
                                            text: journey.description.replace(/_/gi, " ").toLowerCase()
                                        });
                                    }
                                });
                                context.suggestionOptions = suggestionOptions;
                                saveContext();
                                app.sendQuickReplies({
                                    title: app.options.suggestionQuestion,
                                    options: options
                                });
                                resolve();
                            });

                        } else {
                            app.ask(app.referrer);
                            resolve();
                        }
                    } else {
                        app.ask(app.referrer);
                        resolve();
                    }

                    //  below code shouldn't execute and stopping child bots from pushing to unknown utterances
                    return;
                }
                app.log(app.data.message, "unidentified utterance");
                // Add to unidentified list
                if (app.options.saveUnknownMessage === undefined || app.options.saveUnknownMessage) {
                    app.ai.addToUnIdentifiedList(app.data.message, app.sender, app.source).then(() => {
                        app.analytics.incrementInternal("unknown-message", {message: app.data.message})
                    }, () => {
                    });
                }
            }
            // Data used for response templates
            let dataProps = {
                source: app.source,
                options: app.options,
                profile: app.profile,
                steps: context.steps,
                data: app.data

            };

            if (journeyDetails.actions && journeyDetails.actions.length > 0) {
                if (app.prediction && app.messageId()) {
                    vault.updateMessage(app.messageId(), {
                        "slug": `${context.journeyName}:response`,
                        "data": {"sentiment": app.prediction.sentiment}
                    });
                }

                let sendMessage = function (n) {
                    if (journeyDetails.actions[n]) {
                        let response = journeyDetails.actions[n];
                        if (app.options.targetLanguage && app.options.targetLanguage !== "en" && response.locale && response.locale[app.options.targetLanguage]) {
                            response = response.locale[app.options.targetLanguage];
                            selectMessageType(response, dataProps).then(() => {
                                sendMessage(n + 1);
                            })
                        } else if (response.type !== 'func' && app.options.targetLanguage && app.options.targetLanguage !== "en" && !(response.locale && response.locale[app.options.targetLanguage]) && app.options.i18n) {
                            // setting it to false for translating response if its not in db
                            app.options.i18n = false;
                            selectMessageType(response, dataProps).then(() => {
                                // going back to default state
                                app.options.i18n = true;
                                sendMessage(n + 1);
                            })
                        } else {
                            selectMessageType(response, dataProps).then(() => {
                                sendMessage(n + 1);
                            })
                        }

                    } else {
                        resolve();
                    }
                };

                sendMessage(0);
            } else {
                app.sendWelcomeMessage(app.options.unknownMessage);
                resolve();
            }
        });
    };

    /**
     *  Processing the action
     * @param prediction
     * @param data data from the user
     * @returns {Promise}
     */
    this.processAction = function (prediction, data) {
        return new Promise(function (resolve, reject) {
            let intent;
            let index = -1;
            if (context && context.suggestionOptions) {
                // if suggestions are there then it is compared with message and if it matches then intent is updated with the particular slug
                if (app.data && app.data.message) {
                    index = _.findIndex(context.suggestionOptions, (option) => {
                        return option.text === app.data.message.toLowerCase();
                    });
                    if (index !== -1) {
                        intent = context.suggestionOptions[index].slug;
                    }
                }
                delete context.suggestionOptions;
                saveContext();
            }
            if (prediction.confidence < app.options.minConfidence && (context.complete || context.complete === undefined) && index === -1) {
                intent = 'default';
                context.paramExpected = 'default';
                context.intent = 'default';
                if (botMapping && botMapping.skin && botMapping.skin.defaultAutoComplete) {
                    app.xmppObj.defaultAutoComplete = botMapping.skin.defaultAutoComplete;
                }
            }
            if (intent !== 'default' && index === -1) {
                intent = ((prediction.confidence >= app.options.contextConfidence || context.complete || context.complete === undefined)
                    && app.options.intentSwitchExclusions.indexOf(prediction.intent) === -1 && app.options.excludeParamsForSwitching.indexOf(context.paramExpected) === -1) ? prediction.intent : context.intent;
            }

            function performAction(journeyDetails) {
                let promises = [];
                let contextEntitiesIdentified = false;
                delete context.error;
                let originalMessage = app.data.message;
                //if errorQuestion is not defined there then next step is allowed
                let postValidation = function (errorHandler) {
                    return new Promise(function (resolve) {
                        if (!errorHandler) {
                            context.invalidCount = 0;
                            if (!context.steps) {
                                context.steps = {};
                            }
                            if (!context.steps[context.paramExpected]) {
                                context.steps[context.paramExpected] = app.data.message || app.data.location || app.data.file || app.data.image || app.data.audio || app.data.video;
                                if (context['steps'][context.paramExpected]) {
                                    app.analytics.incrementInternal("step-updated", _.assign({message: app.data.message | ""}, {
                                        journey: context.journeyName,
                                        name: context.paramExpected
                                    }));
                                } else {
                                    app.analytics.incrementInternal("step-recorded", _.assign({message: app.data.message | ""}, {
                                        journey: context.journeyName,
                                        name: context.paramExpected
                                    }));
                                }
                            }
                            resolve();
                        } else {
                            if (app.options.invalidCount && context.invalidCount >= app.options.invalidCount && app.options.onInvalidCountExceeded) {
                                delete context.invalidCount;
                                app.context = context;
                                app.options.onInvalidCountExceeded();
                                resolve();
                            }
                            else {
                                if (!context.invalidCount) {
                                    context.invalidCount = 1;
                                } else {
                                    context.invalidCount++;
                                }
                                //if type is function then errorHandler is executed otherwise it is sent as text message
                                if (typeof errorHandler === "function") {
                                    let result = errorHandler();
                                    if (result instanceof Promise) {
                                        result.then(() => {
                                            resolve();
                                        })
                                    } else {
                                        resolve();
                                    }

                                } else {
                                    app.sendTextMessage(errorHandler);
                                    resolve();
                                }
                                app.context = context;
                            }
                        }
                    });
                };

                let afterPostValidation = function () {
                    return new Promise((resolve) => {
                        nextStep(journeyDetails);
                        //updating the context inside the app object
                        app.context = context;
                        if (!context.complete) {
                            askStep(context, journeyDetails._id)
                                .then(function () {
                                    resolve();
                                });
                        } else {
                            // Complete journey
                            completeJourney(prediction, journeyDetails)
                                .then(function () {
                                    resolve();
                                });
                        }
                    });
                };

                let promisesArray = [];
                let validateStep = (stepSlug) => {
                    return new Promise((resolve) => {
                        app.getStepDetails(journeyDetails._id, stepSlug).then((stepDetails) => {
                            if (!stepDetails) {
                                return resolve({success: true});
                            }
                            app.xmppObj = _.assign(app.xmppObj, {
                                stepId: stepDetails._id,
                                stepName: stepDetails.name,
                                stepSlug: stepDetails.slug,
                            });
                            app.xmppObj.stepAutoComplete = stepDetails.autoComplete;
                            if (prediction.global_model && prediction.global_model.confidence && prediction.global_model.confidence > app.options.secondaryModelConfidence && stepDetails.responses && stepDetails.responses[prediction.global_model.intent] && stepDetails.responses[prediction.global_model.intent].length > 0) {
                                let dataProps = {
                                    source: app.source,
                                    options: app.options,
                                    profile: app.profile,
                                    steps: context.steps,
                                    data: app.data

                                };
                                let sendMessage = function (n) {
                                    if (stepDetails.responses[prediction.global_model.intent][n]) {
                                        let response = stepDetails.responses[prediction.global_model.intent][n];
                                        if (app.options.targetLanguage && app.options.targetLanguage !== "en" && response.locale && response.locale[app.options.targetLanguage]) {
                                            response = response.locale[app.options.targetLanguage];
                                        }
                                        return selectMessageType(response, dataProps).then(() => {
                                            sendMessage(n + 1);
                                        })

                                    } else {
                                        resolve({success: false});
                                    }
                                };
                                sendMessage(0);
                            }
                            else {
                                let processValidators = function (n) {
                                    return new Promise((resolve, reject) => {
                                        if (stepDetails.validators && stepDetails.validators[n]) {
                                            let result = app.functionWrapper(stepDetails.validators[n].func, stepDetails.validators[n].args);
                                            if (result instanceof Promise) {
                                                result.then((res) => {
                                                    if ((res && res.success) || !res) {
                                                        processValidators(n + 1).then(() => {
                                                            resolve();
                                                        }, (res) => {
                                                            return reject(res)
                                                        })
                                                    }
                                                    else {
                                                        return reject(res);
                                                    }
                                                }, () => {
                                                    reject();
                                                });
                                            }
                                            else {
                                                app.log(`${stepDetails.validators[n].func} doesn't return a Promise`)
                                            }
                                        }
                                        else {
                                            return resolve();
                                        }
                                    })

                                };
                                processValidators(0).then(() => {
                                    postValidation().then(() => {
                                        return resolve({success: true});
                                    })

                                }, (response) => {
                                    if (!response) {
                                        return resolve({success: false});
                                    } else if (response.customHandler) {
                                        return resolve({success: false, customHandler: response.customHandler});
                                    } else {
                                        return resolve({success: false, errorQuestion: response.question});
                                    }

                                })

                            }
                        })
                    });
                };

                if (Object.keys(prediction.entities).length > 0 && journeyDetails.steps) {
                    for (let entity in prediction.entities) {
                        if (prediction.entities.hasOwnProperty(entity)) {
                            let param = undefined;
                            for (let idx = 0; idx < journeyDetails.steps.length; idx++) {
                                if (journeyDetails.steps[idx].entity === entity) {
                                    if (context.steps) {
                                        //looping through the whole entities to check whether the param is already in the context or not
                                        let allParams = Object.keys(context.steps);
                                        let j = 0;
                                        for (; j < allParams.length; j++) {
                                            if (allParams[j] === journeyDetails.steps[idx].slug) {
                                                break;
                                            }
                                        }
                                        if (j >= allParams.length) {
                                            param = journeyDetails.steps[idx].slug;
                                            break;
                                        }

                                    }
                                    else {
                                        param = journeyDetails.steps[idx].slug;
                                        break;
                                    }

                                }
                            }

                            if (param) {
                                contextEntitiesIdentified = true;
                                promisesArray.push(new Promise((resolve) => {
                                    if (typeof (prediction.entities[entity]) === "string") {
                                        app.data.message = prediction.entities[entity];
                                    } else {
                                        let value = prediction.entities[entity][0].value;
                                        if (typeof value === "string") {
                                            app.data.message = value;
                                        } else {
                                            app.data.message = value.value;
                                        }
                                    }
                                    validateStep(param).then((results) => {
                                        resolve(results);
                                    })
                                }));
                            }
                        }
                    }
                }

                if (!contextEntitiesIdentified && context.paramExpected) {
                    if (data) {
                        promisesArray.push(new Promise((resolve) => {
                            validateStep(context.paramExpected).then((results) => {
                                resolve(results);
                            })
                        }));
                    }
                }
                let success = true;
                app.q.allSettled(promisesArray).then(function (arrayOfResults) {
                    app.data.message = originalMessage;
                    let allErrorFunctions = [];
                    arrayOfResults.forEach((e) => {
                        if (e.value && !e.value.success && (e.value.errorQuestion || e.value.customHandler)) {
                            allErrorFunctions.push(() => {
                                return postValidation(e.value.customHandler || e.value.errorQuestion);
                            });
                        }
                        if (e.value && e.value.success === false) {
                            success = false;
                        }
                    });
                    if (allErrorFunctions.length === 0 && success) {
                        afterPostValidation().then(() => {
                            return resolve();
                        });
                    } else if (allErrorFunctions.length !== 0 && !success) {
                        //running all error functions one by one
                        allErrorFunctions.reduce((promiseChain, currentTask) => {
                            return promiseChain.then(chainResults =>
                                currentTask().then(currentResult =>
                                    [...chainResults, currentResult]
                                )
                            );
                        }, Promise.resolve([])).then(() => {
                            return resolve();
                        });
                    } else {
                        return resolve();
                    }
                });

            }

            app.getJourney(intent)
                .then(function (journeyDetails) {
                    // No action defined for intent
                    context.journeyName = journeyDetails.name;
                    context.journeyId = journeyDetails._id;
                    app.xmppObj = _.assign(app.xmppObj, {
                        journeyId: journeyDetails._id,
                        journeyName: journeyDetails.name,
                        journeySlug: intent
                    });
                    if (journeyDetails && journeyDetails.categoryType && app.prediction) {
                        app.prediction.categoryType = journeyDetails.categoryType;
                    }
                    if ((!journeyDetails || journeyDetails.steps.length === 0) && !journeyDetails.initFunction) {
                        context.complete = true;
                        return completeJourney(prediction, journeyDetails)
                            .then(function () {
                                resolve();
                            });
                    }

                    // Init function to be called if the context has just switched and didn't start
                    // Continue only if this resolves or returns a true
                    if (context.intent === intent && context.complete === undefined && journeyDetails.initFunction) {
                        if (app.allFunctions[journeyDetails.initFunction]) {
                            let initResult = app.executeFunction(journeyDetails.initFunction);
                            if (initResult instanceof Promise) {
                                initResult.then(function () {
                                    performAction(journeyDetails);
                                }, function () {
                                    resolve();
                                })
                            } else if (initResult) {
                                performAction(journeyDetails);
                            }
                        } else {
                            performAction(journeyDetails)
                        }
                    } else {
                        performAction(journeyDetails);
                    }
                }, () => {
                    return completeJourney(prediction, undefined)
                        .then(function () {
                            context.complete = true;
                            resolve();
                        });
                });
        });
    };

    let askStep = function (context, journeyId) {
        return new Promise((resolve) => {
            if (app.prediction && app.messageId()) {
                vault.updateMessage(app.messageId(), {
                    "slug": `${context.journeyName}:${context.paramExpected}`,
                    "data": {"sentiment": app.prediction.sentiment}
                });
            }

            app.getStepDetails(journeyId, context.paramExpected).then((stepDetails) => {
                app.xmppObj = _.assign(app.xmppObj, {
                    stepId: stepDetails._id,
                    stepName: stepDetails.name,
                    stepSlug: stepDetails.slug
                });
                let dataProps = {
                    source: app.source,
                    options: app.options,
                    profile: app.profile,
                    steps: context.steps,
                    data: app.data

                };
                app.xmppObj.stepId = stepDetails._id;
                app.xmppObj.stepName = stepDetails.name;
                app.xmppObj.stepSlug = stepDetails.slug;
                app.xmppObj.stepAutoComplete = stepDetails.autoComplete;
                let sendMessage = function (n) {
                    if (stepDetails.prompts && stepDetails.prompts[n]) {
                        let response = stepDetails.prompts[n];
                        if (app.options.targetLanguage && app.options.targetLanguage !== "en" && response.locale && response.locale[app.options.targetLanguage]) {
                            response = response.locale[app.options.targetLanguage];
                            return selectMessageType(response, dataProps).then(() => {
                                sendMessage(n + 1);
                            })
                        } else if (response.type !== 'func' && app.options.targetLanguage && app.options.targetLanguage !== "en" && !(response.locale && response.locale[app.options.targetLanguage]) && app.options.i18n) {
                            // setting it to false for translating response if its not in db
                            app.options.i18n = false;
                            return selectMessageType(response, dataProps).then(() => {
                                // going back to default state
                                app.options.i18n = true;
                                sendMessage(n + 1);
                            })
                        } else {
                            return selectMessageType(response, dataProps).then(() => {
                                sendMessage(n + 1);
                            })
                        }

                    } else {
                        resolve();
                    }
                };

                sendMessage(0);
            })

        })


    };

    let generateOptions = function (optionString) {
        let dataProps = {source: app.source, options: app.options, profile: app.profile, params: context.steps};

        let options = [];
        let optionsBroken = optionString.split(",");
        for (let i = 0; i < optionsBroken.length; i++) {
            let option = optionsBroken[i].split("::");
            if (option.length > 1) {
                let title = app.mustache.render(option[0], dataProps);
                let text = app.mustache.render(option[1] || option[0], dataProps);
                options.push({title: title, text: text, primary: !!option[2], image: option[3]});
            } else {
                let option = optionsBroken[i].split(":");
                let title = app.mustache.render(option[0], dataProps);
                let text = app.mustache.render(option[1] || option[0], dataProps);
                options.push({title: title, text: text, primary: !!option[2], image: option[3]});
            }
        }
        return options;
    };

    let saveContext = function () {
        return app.memory.set("context", JSON.stringify(context));
    };

    this.saveMessage = function () {
        try {
            if (!context.dataHistory) {
                context.dataHistory = [];
            }
            context.dataHistory.push({
                data: app.data,
                intent: app.prediction ? app.prediction.intent : "",
                confidence: app.prediction ? app.prediction.confidence : 1,
            });
            context.dataHistory = context.dataHistory.splice(-1 * 5);
        } catch (e) {
        }
        saveContext();
    };

    // Get the context
    this.getContext = function () {
        return new Promise(function (resolve, reject) {
            loadContext().then(function () {
                resolve(context);
            })
        })
    };

    this.resetContext = function (contextData) {
        context = contextData;
        app.context = contextData;
        return saveContext();
    };

    // Start the form
    this.changeJourney = function (prediction, data) {
        return new Promise(function (resolve, reject) {
            loadContext().then(function () {
                // Clear the context
                self.clearContext();

                context.intent = prediction.intent;

                saveContext();

                self.processAction(prediction, data).then(function () {
                    // context.complete is checked to handle cases where in complete action trigger intent is used
                    if (context.complete) {
                        self.clearContext().then(() => {
                            resolve(context);
                        });
                    } else {
                        saveContext();
                        resolve(context);
                    }
                }, function () {
                    reject("No action");
                });
            });
        });
    };

    //  Context params to be cleared
    this.clearContext = function () {
        //TODO Save the old context for a recall
        if (!context.history) {
            context.history = [];
        }

        if (context.intent) {
            context.history.push({
                intent: context.intent,
                complete: context.complete,
                steps: _.cloneDeep(context.steps)
            });
            // Store only last 10 intents in the memory
            context.history = context.history.splice(-1 * 5);
        }

        // Store the previous entities as well
        delete context.paramExpected;
        delete context.question;
        delete context.options;
        delete context.steps;
        delete context.complete;
        delete context.invalidCount;
        delete context.intent;
        delete context.journeyName;
        delete context.journeyId;
        delete context.stepId;
        app.context = context;
        return saveContext();
    };


    this.setContextParam = function (entity, value) {
        if (!context) {
            loadContext().then(function () {
                if (!context.steps) {
                    context.steps = {};
                }
                if (context['steps'][entity]) {
                    app.analytics.incrementInternal("step-updated", _.assign({message: value}, {
                        journey: context.journeyName,
                        name: entity
                    }));
                } else {
                    app.analytics.incrementInternal("step-recorded", _.assign({message: value}, {
                        journey: context.journeyName,
                        name: entity
                    }));
                }
                context.steps[entity] = value;
                app.context = context;
                return saveContext();
            });
        } else {
            if (!context.steps) {
                context.steps = {};
            }
            if (context['steps'][entity]) {
                app.analytics.incrementInternal("step-updated", _.assign({message: value}, {
                    journey: context.journeyName,
                    name: entity
                }));
            } else {
                app.analytics.incrementInternal("step-recorded", _.assign({message: value}, {
                    journey: context.journeyName,
                    name: entity
                }));
            }
            context.steps[entity] = value;
            app.context = context;
            return saveContext();
        }
    };

    this.setContextMultiple = function (paramObject) {
        if (paramObject && typeof (paramObject) === 'object' && !(paramObject instanceof Array) && !(paramObject instanceof Date)) {
            if (!context) {
                return loadContext().then(function () {
                    if (!context.steps) {
                        context.steps = {};
                    }
                    Object.keys(paramObject).forEach(function (key) {
                        if (context['steps'][key]) {
                            app.analytics.incrementInternal("step-updated", _.assign({message: paramObject[key]}, {
                                journey: context.journeyName,
                                name: key
                            }));
                        } else {
                            app.analytics.incrementInternal("step-recorded", _.assign({message: paramObject[key]}, {
                                journey: context.journeyName,
                                name: key
                            }));
                        }
                        context['steps'][key] = paramObject[key];
                    });
                    app.context = context;
                    return saveContext();
                });
            } else {
                if (!context.steps) {
                    context.steps = {};
                }
                Object.keys(paramObject).forEach(function (key) {
                    if (context['steps'][key]) {
                        app.analytics.incrementInternal("step-updated", _.assign({message: paramObject[key]}, {
                            journey: context.journeyName,
                            name: key
                        }));
                    } else {
                        app.analytics.incrementInternal("step-recorded", _.assign({message: paramObject[key]}, {
                            journey: context.journeyName,
                            name: key
                        }));
                    }
                    context['steps'][key] = paramObject[key];
                });
                app.context = context;
                return saveContext();
            }
        } else {
            app.log('insert only objects');
        }
    };


    this.deleteContextParam = function (entity, value) {
        if (!context) {
            return loadContext().then(function () {
                if (context.steps && context.steps[entity]) {
                    delete context.steps[entity];
                }
                app.context = context;
                return saveContext();
            });
        } else {
            if (context.steps && context.steps[entity]) {
                delete context.steps[entity];
            }
            app.context = context;
            return saveContext();
        }
    };


    // Process Context
    this.process = function (prediction, data) {
        return new Promise(function (resolve, reject) {
            loadContext().then(function () {
                // Process and resolve
                self.processAction(prediction, data).then(function () {
                    if (context.complete) {
                        self.clearContext().then(() => {
                            resolve(context);
                        });
                    } else {
                        app.processEndTime = new Date();
                        saveContext();
                        resolve(context);
                    }
                });

            }, function (e) {
                reject(e);
            });
        });
    };
};


// Sending messages
let App = function (options) {
    // options : sender, bot, source, data, mapping, profile
    // All private variables
    let sender = options.sender;
    let bot = options.bot;
    let mapping = options.mapping;
    let source = options.source;
    let profile = options.profile;
    let profileOriginal = _.clone(profile, true);
    let botIdentifier = options.botIdentifier;

    let maximumAssignedCount = mapping && mapping.maximumAssignedCount || undefined;
    //for Google assistant
    let googleConversationId = options.data && options.data.conversationId ? options.data.conversationId : '';
    let googleSurfaceCapabilities = options.data && options.data.capabilities ? options.data.capabilities : [];

    //for slack
    let slackChannel = options.data && options.data.slackChannel ? options.data.slackChannel : '';
    let slackToken = options.data && options.data.slackToken ? options.data.slackToken : '';
    //an array where bot responses are saved before pushing to vault
    let messageArray = [];
    //for facebook
    let signature = '6cab9a2aada111452fa2db8ba663fb6e29208d76e6b27b8ec75e97482bf70d2f';

    let publish = options.publish;
    let self = this;
    //saving the messageId and sessionId
    let messageId = options.messageId;

    let runDefaultFunction = options.runDefaultFunction;
    let sessionObject = options.sessionObject;
    let sessionId = sessionObject && sessionObject.sessionId ? sessionObject.sessionId : undefined;
    let receivedMessageTime = options.receivedMessageTime;
    this.bot = options.bot;
    this.botIdentifier = botIdentifier;
    //an object is made for passing  journey and step info to xmpp
    this.xmppObj = {};

    this.referrer = options.referrer;
    // triggerJourney is assigned for defaultFunction to handle journey in the bot
    this.triggerJourney = options.triggerJourney;
    this.orchestratorBotId = options.orchestratorBotId;
    this.allFunctions = options.allFunctions;
    this.term = options.term;
    this.messageId = function () {
        return messageId;
    };
    this.sessionId = function () {
        return sessionId;
    };
    // Non private
    this.source = options.source;
    this.sender = options.sender;
    this.data = options.data;
    this.profile = options.profile;

    // External Libraries
    this.imageRequest = imageRequest;
    this.fileRequest = self.imageRequest;
    this.q = Q;
    this.xmlToJSON = xml2json;
    this.stringMatch = stringMatch;
    this.numeral = numeral;
    this.axios = axios;
    this.geolib = geolib;
    this.time = time;
    this._ = _;
    this.crypto = crypto;
    this.cheerio = cheerio;
    this.sanitizeHTML = sanitizeHtml;
    this.mustache = mustache;
    this.translate = translateClient;
    this.phoneParse = phoneParse;
    this.phonetics = phonetics;
    this.soap = soap;

    this.insecureAgent = new https.Agent({
        rejectUnauthorized: false
    });

    //Utilities
    this.random = Math.random;
    this.floor = Math.floor;
    this.ceil = Math.ceil;

    // Yellow Messenger Libraries
    this.dataStore = new DataStore(bot);
    this.datastore = this.dataStore;
    this.ai = new AI(bot);

    // Prediction
    this.predict = function () {
        if (self.data.message) {
            if (self.options.targetLanguage !== 'en') {
                translateClient.translate(self.data.message, 'en', (err, translation) => {
                    self.data.message = translation;
                    return self.ai.predict(self.data.message, "", self.options.entityThreshold, self.options.spellCorrection);
                });
                return;
            }
            return self.ai.predict(self.data.message, "", self.options.entityThreshold, self.options.spellCorrection);
        } else {
            return Promise.resolve({});
        }
    };

    this.memory = new Memory(bot, sender);
    //This function will give you a encrypted logs link to the current user.
    this.getMessageLogUrl = () => {
        return 'https://app.yellowmessenger.com/#/public/messages/' + encrypt(`${bot}&&${sender}&&${source}`)
    };

    this.getSessionMessageLogUrl = () => {
        const token = encrypt(`${bot}&&${sender}&&${source}`);
        return `https://app.yellowmessenger.com/#/public/messages/${token}/${sessionId}`;
    };

    this.getTimeStampMessagesLogUrl = (startTime, endTime) => {
        const token = encrypt(`${bot}&&${sender}&&${startTime}&&${endTime}`);
        return `https://app.yellowmessenger.com/#/public/messages/${token}/timestamp`;
    }

    this.encrypt = encrypt;
    this.decrypt = decrypt;
    this.analytics = new Analytics(sender, bot, source, profile, self.data);
    this.knowledge = knowledge;
    this.sendEmail = mailer.sendEmail;
    this.logger = new Logger(bot, sender, source);
    this.log = this.logger.log;
    this.getJourney = function (intent) {
        return actionLib.getJourney(intent, bot);
    };

    this.getStepDetails = function (intent, slug) {
        return actionLib.getStep(intent, slug)
    };
    this.getMultipleJourneysBySlug = function (journeySlugs) {
        return actionLib.getMultipleJourneysBySlug(journeySlugs, bot);
    };
    this.getMultipleJourneysByCategoryType = function (categoryType) {
        return this.dataStore.search({
            table: "alljourneys",
            body: {
                query: {
                    match: {
                        categoryType: categoryType
                    }
                }
            }
        }).then((results) => {
            return Promise.resolve(results.hits.total > 0 ? _.map(_.filter(results.hits.hits, function (hit) {
                return hit._source.categoryType.toLowerCase() === categoryType.toLowerCase();
            }), function (hit) {
                return {
                    name: hit._source.name,
                    description: hit._source.description,
                    categoryType: hit._source.categoryType,
                    slug: hit._source.slug
                };
            }) : []);
        }, (error) => {
            return Promise.reject(error);
        });
    };
    this.actions = {};
    this.getFile = function (url) {
        return new Promise(function (resolve, reject) {
            self.fileRequest.get(url, function (error, response, body) {
                if (!error && response.statusCode === 200) {
                    resolve(new Buffer(body));
                } else {
                    reject(error);
                }
            });
        });
    };

    this.request = request;
    this.requestretry = require('requestretry');
    this.executeFunction = function (funcName, args, defaultPrompt) {
        if (runDefaultFunction && defaultPrompt) {
            return self.functionWrapper(funcName, args).then(() => {
                publish(true, 'success', {
                    'messageArray': messageArray
                });
                return Promise.resolve();
            })
        } else {
            return self.functionWrapper(funcName, args);
        }
    };

    this.functionWrapper = (funcName, args) => {
        return new Promise((resolve, reject) => {
            const startTime = new Date();
            return self.allFunctions[funcName](self, self, args).then((data) => {
                resolve(data);
            }, (err) => {
                reject(err);
            }).finally(() => {
                const endTime = new Date();
                self.analytics.incrementInternal("function-execution-time", {
                    name: funcName,
                    args: args,
                }, endTime.getTime() - startTime.getTime());
            });
        });
    };

    this.updateProfile = function () {
        return new Promise((resolve, reject) => {
            vault.saveOrUpdateProfile(self.sender, bot, self.source, self.profile);
            if (self.profile.name !== profileOriginal.name && self.profile.name !== undefined) {
                vault.updateVaultLogName(self.sender, bot, self.source, self.profile.name).then(vaultLog => {
                    return resolve(vaultLog);
                }, (message) => {
                    return reject(message);
                });
            }
        });
    };

    this.updateProfileName = function (newName) {
        return new Promise((resolve, reject) => {
            let nameSplit = newName.split(' ');
            let firstName, lastName, data;
            firstName = nameSplit[0];
            if (nameSplit.length > 1) {
                lastName = nameSplit.slice(1).join(' ');
            }
            if (self.profile) {
                self.profile.first_name = firstName;
                self.profile.last_name = lastName || '';
                self.profile.name = newName
            } else {
                self.profile = {
                    name: newName,
                    first_name: firstName,
                    last_name: lastName || ''
                }
            }
            vault.saveOrUpdateProfile(self.sender, bot, self.source, self.profile);
            vault.updateVaultLogName(self.sender, bot, self.source, newName).then(vaultLog => {
                return resolve(vaultLog);
            }, (message) => {
                return reject(message);
            });
        });
    };

    this.setActionFunctions = function (actionFunctions) {
        this.actions = actionFunctions;
    };

    // Send & Save Email on the Database
    this.sendEmailMessage = function (email) {
        emailSender.sendMessage(sender, {
            email: email
        }, bot, () => {
        });
    };

    this.wordToNumber = function (message) {
        return wordToNumber.getNumber(message)
    };
    this.getphonetics = phonetics.getPhonetics;
    this.machineComprehension = machineComprehension;
    this.searchDocuments = (message, functionScore) => {
        return new Promise((resolve) => {
            request({
                url: `http://documents:7788/documents/search-internal?bot=${bot}&query=${message}&functionScore=${functionScore || false}`,
                method: 'GET',
                json: true,
            }, function (err, resp, body) {
                resolve(body);
            });
        });
    };

    this.fetchDocument = (documentId) => {
        return new Promise((resolve) => {
            request({
                url: `http://documents:7788/documents/document/${documentId}?bot=${bot}`,
                method: 'GET',
                json: true,
            }, function (err, resp, body) {
                resolve(body);
            });
        });
    };

    this.documentUrl = (documentPath) => {
        return new Promise((resolve) => {
            request({
                url: `http://documents:7788/documents/file-internal/${documentPath}?bot=${bot}`,
                method: 'GET',
                json: true,
            }, function (err, resp, body) {
                resolve(body);
            });
        });
    };

    // Send OTP
    let otp = require('./utils/otp');
    this.sendOtp = (number) => {
        return otp.sendOtp(number, this.memory.set);
    };
    this.verifyOtp = (otpTyped) => {
        return otp.verifyOtp(otpTyped, this.memory.get);
    };

    this.delayedMessage = function (event, data, delay, callback) {
        setTimeout(() => {
            rabbit.publish(JSON.stringify({
                sender: sender,
                source: source,
                business: botIdentifier,
                event: event,
                data: data
            }), 'delayed-message-queue', callback);
        }, delay);
    };

    this.renderTemplate = function (text, data) {
        return mustache.render(text, data);
    };

    this.extractName = function (sentence) {
        return new Promise((resolve, reject) => {
            let capitalisedSentence = sentence.replace(/\b\w/g, l => l.toUpperCase());
            self.ai.predict(capitalisedSentence).then((result) => {
                if (typeof result === 'string') {
                    result = JSON.parse(result);
                }
                if (result.parser && result.parser.noun_chunks && result.parser.noun_chunks.length > 0) {
                    for (let i = 0; i < result.parser.noun_chunks.length; i++) {
                        const chunk = result.parser.noun_chunks[i];
                        if (chunk.pos && chunk.pos === 'PROPN') {
                            return resolve(chunk.chunk);
                        }
                    }
                    return reject(new Error('No name found'));
                } else {
                    return reject(new Error('No name found'));
                }
            })
        })
    };

    let contextProcessor = new ContextProcessor(this, mapping);

    let checkContext = function () {
        return new Promise(function (resolve, reject) {
            contextProcessor.getContext().then(function (context) {
                self.contextEndTime = new Date();
                // Predict it
                self.context = context;
                predict(context.intent && context.core ? context.intent : "")
                    .then(function (prediction) {
                        if (prediction.intent === 'none') {
                            prediction.intent = 'default';
                        }
                        self.predictionEndTime = new Date();
                        const AUTHENTICATE_TRUE = true;
                        const AUTHENTICATE_FALSE = false;
                        const RUNPROCESS_TRUE = true;
                        const RUNPROCESS_FALSE = false;

                        let processWithAuthentication = function (authenticate, runprocess) {
                            /*
                                if runprocess then contextProcessor.process is called else contextProcessor.changeJourney is called
                                the authentication function is run only when authenticate is true
                                if authentication function is resolved then the user is authorized
                                if authentication function is rejected then the user is not authorized
                            */
                            if (authenticate) {
                                if (runprocess) {
                                    self.options.authentication(context).then(() => {
                                        contextProcessor.process(prediction, self.data)
                                            .then(function (context) {
                                                resolve(context);
                                            });
                                    }, () => {
                                        return resolve(context)
                                    });
                                } else {
                                    self.options.authentication(context).then(() => {
                                        contextProcessor.changeJourney(prediction, self.data)
                                            .then(function (context) {
                                                resolve(context);
                                            });
                                    }, () => {
                                        return resolve(context)
                                    });
                                }
                            } else {
                                if (runprocess) {
                                    contextProcessor.process(prediction, self.data)
                                        .then(function (context) {
                                            resolve(context);
                                        });
                                } else {
                                    contextProcessor.changeJourney(prediction, self.data)
                                        .then(function (context) {
                                            resolve(context);
                                        });
                                }
                            }
                        };

                        if (self.options.entities) {
                            prediction.entities = _.assign(prediction.entities, self.options.entities);
                        }

                        self.prediction = prediction;

                        contextProcessor.saveMessage();
                        // Reset context only if journey is switched
                        if (!context.intent
                            || (context.intent !== prediction.intent && prediction.confidence >= self.options.contextConfidence && (!self.options.intentSwitchExclusions || self.options.intentSwitchExclusions.indexOf(prediction.intent) === -1) && self.options.excludeParamsForSwitching.indexOf(context.paramExpected) === -1)
                            || (context.intent !== prediction.intent && prediction.confidence >= self.options.minConfidence && (context.complete === undefined || context.complete))
                            || (prediction.confidence >= self.options.minConfidence && context.intent === 'default')) {
                            // if no intents are given in auth options then all intents are authorized
                            if (self.options.authOptions.intents.length === 0) {
                                processWithAuthentication(AUTHENTICATE_TRUE, RUNPROCESS_FALSE);
                            } else {
                                let j = 0;
                                for (; j < self.options.authOptions.intents.length; j++) {
                                    if (self.options.authOptions.intents[j] === prediction.intent) {
                                        break;
                                    }
                                }
                                // if intents is not there in authentication then authentication function is not called
                                if (j >= self.options.authOptions.intents.length) {
                                    processWithAuthentication(AUTHENTICATE_FALSE, RUNPROCESS_FALSE);
                                } else {
                                    processWithAuthentication(AUTHENTICATE_TRUE, RUNPROCESS_FALSE);
                                }
                            }
                        } else {
                            processWithAuthentication(AUTHENTICATE_FALSE, RUNPROCESS_TRUE);
                        }
                    }, function () {
                        contextProcessor.saveMessage();
                        if (context.intent) {
                            contextProcessor.process({
                                intent: context.intent,
                                confidence: 1,
                                entities: []
                            }, self.data)
                                .then(function (context) {
                                    resolve(context);
                                });
                        }
                    });
            });
        });
    };

    this.getContext = contextProcessor.getContext;

    this.customEntityRecognizer = undefined;

    let predict = function (context) {
        return new Promise(function (resolve, reject) {
            if (self.data.message) {
                if (self.options.targetLanguage && self.options.targetLanguage !== 'en' && self.options.translateInputMessages === true) {
                    translateClient.translate(self.data.message, {
                        to: 'en',
                        from: self.options.targetLanguage
                    }, (err, translation) => {
                        self.data.message = translation;
                        self.ai.predict(
                            self.data.message,
                            self.options.enableContextForPrediction ? context : "",
                            self.options.entityThreshold,
                            self.options.spellCorrection,
                            self.options.excludeKeywordsForPrediction
                        ).then(function (prediction) {
                            if (self.customEntityRecognizer) {
                                let result = self.customEntityRecognizer(prediction);
                                if (result instanceof Promise) {
                                    result.then(function (recognizerResult) {
                                        resolve(recognizerResult || prediction)
                                    });
                                } else {
                                    resolve(result || prediction);
                                }
                            } else {
                                resolve(prediction);
                            }
                        }, function () {
                            console.log("Timed out for bot : " + bot + " with text: " + (self.data.message || "no_text") + " sender: " + sender);
                        });
                    });
                } else {
                    self.ai.predict(
                        self.data.message,
                        self.options.enableContextForPrediction ? context : "",
                        self.options.entityThreshold,
                        self.options.spellCorrection,
                        self.options.excludeKeywordsForPrediction
                    ).then(function (prediction) {
                        if (self.customEntityRecognizer) {
                            let result = self.customEntityRecognizer(prediction);
                            if (result instanceof Promise) {
                                result.then(function () {
                                    resolve(prediction)
                                });
                            } else {
                                resolve(prediction);
                            }
                        } else {
                            resolve(prediction);
                        }
                    }, function () {
                        console.log("Timed out for bot : " + bot + " with text: " + (self.data.message || "no_text") + " sender: " + sender);
                    });
                }
            } else {
                reject();
            }
        });
    };

    this.entityValidators = {};
    this.options = {
        minConfidence: .85, // Minimum confidence else none
        contextConfidence: 0.90, // For context switching
        entityThreshold: 0.96, // For entity recognition
        suggestionConfidence: 0.65, // minconfidence for showing suggestion
        suggestionQuestion: 'Did you mean ?', // default suggestion question
        enableSuggestion: false, // by default suggestion is false
        unknownMessage: "I think you are looking for something I cannot help you with.",
        transferToAgent: false, // Handle transfer to Human automatically,
        transferToAgentMessage: 'I am unable to help you with your query at the moment but I can transfer our conversation to my human friend who can help you out.',
        targetLanguage: 'en', // Set the target language to send the message back
        autoResponse: true,
        spellCorrection: true,
        intentSwitchExclusions: [],
        secondaryModelConfidence: 0.84,
        FAQQuery: "",
        i18n: false,
        onInvalidCountExceeded: function () {

        },
        //authentication function which takes array of intents. reject if user is not authorized and resolve if user is authorized
        authentication: function (context) {
            return new Promise((resolve, reject) => {
                return resolve();
            })
        },
        /*authorization options type is custom for custom authentication by default it is set to custom authentication
        intents should be mentioned for which the authentication function should run. if no intents are given then by default all intents will be authorized
        if faq is set true then all faqs are authorized by default it is assumed true*/
        authOptions: {
            "type": "custom",
            "intents": [],
            "faq": true
        },
        shouldFAQSessionEnd: true,
        enableContextForPrediction: false, // Passes the context object to AI if turned to true,
        excludeKeywordsForPrediction: [],
        faqInit: function (context) {
            return new Promise((resolve, reject) => {
                resolve();
            })
        },
        excludeParamsForSwitching: [], //params for journey switching wont be there
        translateInputMessages: true // a variable to for not translating input messages
    };

    this.execStartTime = options.execStartTime;

    this.setTargetLanguage = (targetLanguage) => {
        self.options.targetLanguage = targetLanguage;
    };

    this.clearContext = function () {
        contextProcessor.clearContext();
        if (self.orchestrator) {
            self.orchestrator.clearContext();
        }
    };

    this.setContextParam = contextProcessor.setContextParam;
    this.setContextMultiple = contextProcessor.setContextMultiple;
    this.resetContext = contextProcessor.resetContext;
    this.deleteContextParam = contextProcessor.deleteContextParam;

    this.setStep = contextProcessor.setContextParam;
    this.setMultipleSteps = contextProcessor.setContextMultiple;
    this.setSteps = contextProcessor.setContextMultiple;
    this.resetContext = contextProcessor.resetContext;
    this.deleteStep = contextProcessor.deleteContextParam;


    this.pauseBot = function (expiry) {
        return botHelper.pauseBot(this.bot, this.sender, this.source, expiry);
    };
    this.unPauseBot = function () {
        return botHelper.unPauseBot(this.bot, this.sender, this.source);
    };
    this.isBotPaused = function () {
        return botHelper.isBotPaused(this.bot, this.sender, this.source);
    };

    this.ask = function (botId, data) {
        return new Promise(function (resolve, reject) {
            if (botId !== bot) {
                rabbit.publish(JSON.stringify({
                    sender: sender,
                    source: source,
                    business: botId,
                    data: data || self.data,
                    referrer: bot,
                    orchestratorBotId: self.orchestratorStarted ? bot : undefined
                }), 'delayed-message-queue', resolve);


                // Please don't uncomment this or delete this.
                //  request({
                //     url: 'http://127.0.0.1:8080/yellowmessenger/receive',
                //     method: 'POST',
                //     json: {
                //         bot: botId,
                //         from: sender,
                //         message: JSON.stringify(data||self.data),
                //         referrer: bot,
                //         orchestratorBotId: self.orchestratorStarted ? bot:undefined
                //     }
                // }, function(err,resp,body){
                //     console.log(body);
                // });


            } else {
                reject("Cannot call the same bot");
            }
        });
    };

    this.orchestrator = new Orchestrator(self, mapping);

    this.logTimes = function () {
        try {
            let current = new Date();
            if (self.execStartTime) {
                let times = {
                    total: current.getTime() - self.execStartTime.getTime()
                };
                if (self.libraryStartTime) {
                    times['libraryStart'] = current.getTime() - self.libraryStartTime.getTime();
                }
                if (self.contextEndTime) {
                    times['contextEndTime'] = current.getTime() - self.contextEndTime.getTime();
                }
                if (self.predictionEndTime) {
                    times['predictionEndTime'] = current.getTime() - self.predictionEndTime.getTime();
                }
                if (self.processEndTime) {
                    times['processEndTime'] = current.getTime() - self.processEndTime.getTime();
                }
                self.log(times);
            }
        } catch (e) {

        }
    };

    this.spellCheck = (message) => {
        return new Promise((resolve) => {
            var options = {
                method: 'POST',
                url: 'https://api.cognitive.microsoft.com/bing/v7.0/spellcheck',
                qs: {mode: 'spell'},
                headers:
                    {
                        'ocp-apim-subscription-key': '5aacb252a530441a9bd9881f450459b9',
                        'content-type': 'application/x-www-form-urlencoded'
                    },
                form: {Text: message}
            };

            request(options, function (error, response, body) {
                try {
                    body = JSON.parse(body);
                } catch (e) {
                    // Do Nothing
                }

                if (response.statusCode === 200 || response.statusCode === '200') {
                    if (body && body.flaggedTokens && body.flaggedTokens.length > 0) {
                        let correctedWords = body.flaggedTokens;
                        let correctedMessage = message;
                        _.forEach(correctedWords, c => {
                            try {
                                let regex = new RegExp(c.token, "g");
                                correctedMessage = _.replace(correctedMessage, regex, c.suggestions[0].suggestion);
                            } catch (e) {

                            }
                        });
                        return resolve({
                            success: true,
                            message,
                            correctedMessage
                        });
                    }
                }
                return resolve({
                    success: false,
                    message
                })

            });

        });
    };

    this.execCount = 0;

    this.start = function (options) {
        self.execCount++;
        if (self.execCount >= 3) {
            return new Promise(function (resolve) {
                resolve();
            });
        }

        self.libraryStartTime = new Date();
        return new Promise(function (resolve) {
            // passing the targetLanguage to xmpp object
            self.xmppObj.targetLanguage = options && options.targetLanguage ? options.targetLanguage : 'en';
            if (options) {
                self.options = _.assign(self.options, options);
            }

            if (self.data.event && self.data.event.code && self.data.event.code.indexOf("ym_") === 0) {
                self.logTimes();
                return resolve();
            }
            checkContext().then(function () {
                if (source === 'googleAssistant') {
                    publish(true, 'success', {
                        'messageArray': messageArray,
                        'conversationId': googleConversationId,
                        'surfaceCapalibilities': googleSurfaceCapabilities
                    });
                    self.logTimes();
                    resolve();
                }
                else if (source === 'voice') {
                    publish(true, 'success', {
                        'messageArray': messageArray,
                    });
                    self.logTimes();
                    resolve();
                }
                else {
                    self.logTimes();
                    resolve();
                }

            })
        });
    };

    this.publish = (messages) => {
        publish(true, 'success', {
            'messageArray': messages,
        });
    };

    this.triggerIntent = function (intent, entities, params) {
        return new Promise(function (resolve) {
            contextProcessor.getContext().then(function (context) {
                let prediction = {
                    confidence: 1,
                    intent: intent,
                    entities: _.mapValues(entities || {}, function (val, key) {
                        let values = [];
                        if (!(val instanceof Array)) {
                            val = [val];
                        }
                        for (let i = 0; i < val.length; i++) {
                            values.push({
                                text: val[i],
                                value: val[i],
                            });
                        }
                        return values;
                    })
                };
                self.prediction = prediction;
                if (params && typeof (params) === 'object' && !(params instanceof Array) && !(params instanceof Date)) {
                    delete context.paramExpected;
                    delete context.question;
                    delete context.options;
                    delete context.questionOptions;
                    delete context.questionFunction;
                    delete context.complete;
                    delete context.invalidCount;
                    context.steps = {};
                    Object.keys(params).forEach(function (key) {
                        context['steps'][key] = params[key]

                    });
                    context.intent = prediction.intent;
                    self.context = context;
                    contextProcessor.processAction(prediction).then(() => {
                        contextProcessor.resetContext(context);
                        resolve(context);
                    });
                }
                else {
                    contextProcessor.changeJourney(prediction)
                        .then(function (context) {
                            resolve(context);
                        });
                }

            });
        });
    };

    this.invokeJourney = self.triggerIntent;

    this.getProfile = function () {
        return options.profile;
    };

    self.saveAdditionalDataToMessage = function (dataToAttached) {
        return Promise.resolve()
    };

    //TODO - Deprecate once updated in BAGIC
    this.createTicket = function (issue, contact, route, manualAssignment) {
        return new Promise((resolve, reject) => {
            let data = {
                botId: bot,
                source: source,
                userId: sender,
                issue: issue,
                contact: contact
            };

            agents.createTicket(mapping, route, data, manualAssignment).then((assignedData) => {
                return resolve(assignedData);
            }, (err) => {
                return reject(err);
            });
        });
    };

    this.raiseTicket = function (ticketOptions) {
        return new Promise((resolve, reject) => {
            if (!ticketOptions.contact && !ticketOptions.contact.name && !ticketOptions.contact.phone && !ticketOptions.contact.email) {
                return reject({
                    Error: 'Email, Phone and Email are mandatory',
                    Usage: `contact: {
                                name: Yellow Messenger
                                email: test@yellowmessenger.com
                                phone: 9898989898`
                });
            }
            if (!ticketOptions.issue) {
                return reject({
                    Error: 'Issue title and description is mandatory',
                    Usage: `issue: description of issue`
                });
            }
            let category = ticketOptions.category; // eg. ['sales']
            let contact = ticketOptions.contact; // { email: test@yellowmessenger.com, phone: 9898989898, name: 'Yellow Messenger' }
            let priority = ticketOptions.priority; // 'LOW/'MEDIUM'/'HIGH'
            let severity = ticketOptions.severity; // 'LOW/'MEDIUM'/'HIGH'
            let tags = ticketOptions.tags;
            let issue = ticketOptions.issue;

            let requestObj = {
                botId: bot,
                uid: sender,
                source,
                issue,
                category,
                priority,
                severity,
                tags,
                contact
            };

            if (maximumAssignedCount !== undefined) {
                requestObj['maximumAssignedCount'] = maximumAssignedCount;
            }

            agentsInstance.post('/tickets/internal/create', requestObj).then(response => {
                let ticketData = response.data.data;
                if (ticketData && ticketData.assignedTo) {
                    this.pauseBot();
                    return resolve(ticketData);
                }
                else {
                    return resolve(ticketData);
                }
            }, (error) => {
                return reject(error);
            })
        });
    };

    this.agentsAvailable = function () {
        return new Promise((resolve, reject) => {
            agentsInstance.post('/tickets/internal/agents-available', {
                botId: bot,
            }).then(response => {
                if (response.data.success) {
                    return resolve();
                } else {
                    return reject();
                }
            }, (error) => {
                return reject(error);
            });
        });
    };

    this.agentsOnline = self.agentsAvailable;


    this.renderMessage = function (code, data, defaultMessage) {
        let message = (self.options.targetLanguage && self.options.targetLanguage !== "en" ? mapping.configMessagesLocale[self.options.targetLanguage][code] : null)
            || mapping.configMessages[code] || config.messages[code] || defaultMessage || "Message not found with code " + code;
        return mustache.render(message.replace(/\\\\n/g, "\n"), data || {});
    };

    let sendMessage;
    switch (source) {
        case 'alexa':
            sendMessage = alexa.sendMessage;
            break;
        case 'kookoo':
            sendMessage = kookoo.sendMessage;
            break;
        case 'facebook':
            sendMessage = facebook.sendMessageBeta;
            break;
        case 'googleAssistant':
            sendMessage = googleAssistant.sendMessage;
            break;
        case 'yellowmessenger':
            sendMessage = ym.sendMessage;
            break;
        case 'telegram':
        case 'msteams':
        case 'botframework':
        case 'skype':
        case 'slack':
        case 'webchat':
            sendMessage = botframework.sendMessage;
            break;
        case 'email':
            sendMessage = self.sendEmailMessage;
            break;
        case 'sms':
            sendMessage = sms.sendMessage;
            break;
        case 'line':
            sendMessage = line.sendMessage;
            break;
    }
    self.sendWelcomeMessage = function (msg, paramOptions) {
        let externalMessage = false;
        if (msg && msg.length > 0) {
            externalMessage = true;
        }
        let message = msg || mapping.welcomeMessage;

        if (!message) {
            message = "Hello!";
        }
        if (mapping.welcomeMessages && mapping.welcomeMessages.length > 0) {

            if (externalMessage) {
                // Check for Quick Replies or Cards as the last message and send it with the current Message;
                let cards = _.filter(mapping.welcomeMessages, w => {
                    if (w.type === "Cards") {
                        return w;
                    }
                });

                let quickReplies = _.filter(mapping.welcomeMessages, w => {
                    if (w.type === "QuickReplies") {
                        return w;
                    }
                });

                if (quickReplies && quickReplies.length > 0) {
                    if (self.options.targetLanguage && self.options.targetLanguage !== "en" && quickReplies[0].locale && quickReplies[0].locale[self.options.targetLanguage]) {
                        quickReplies[0] = quickReplies[0].locale[self.options.targetLanguage];
                    }
                    return self.sendQuickReplies({
                        title: message,
                        options: quickReplies[0].quickReplies.options
                    }, paramOptions);
                } else if (cards && cards.length > 0) {
                    if (self.options.targetLanguage && self.options.targetLanguage !== "en" && cards[0].locale && cards[0].locale[self.options.targetLanguage]) {
                        cards[0] = cards[0].locale[self.options.targetLanguage];
                    }
                    return self.sendTextMessage(message).then(() => {
                        self.sendCards(cards[0].cards, paramOptions);
                    }, paramOptions);
                } else {
                    return self.sendTextMessage(message, paramOptions);
                }
            }

            let welcomeMessage = mapping.welcomeMessages[0];
            if (self.options.targetLanguage && self.options.targetLanguage !== "en" && welcomeMessage.locale && welcomeMessage.locale[self.options.targetLanguage]) {
                welcomeMessage = welcomeMessage.locale[self.options.targetLanguage];
            }

            if (welcomeMessage.hideInput) {
                if (!paramOptions) {
                    paramOptions = {};

                }
                paramOptions.hideInput = true;
            }

            if (welcomeMessage.type === "Message") {
                if (msg) {
                    return self.sendTextMessage(msg, paramOptions);
                }
            }

            if (welcomeMessage.type === "QuickReplies") {
                if (msg) {
                    welcomeMessage.quickReplies.title = msg;
                }
                return self.sendQuickReplies(welcomeMessage.quickReplies, paramOptions);
            }

            if (welcomeMessage.type === "Image") {
                return self.sendImage(welcomeMessage.image, paramOptions);
            }

            if (welcomeMessage.type === "Email") {
                let to = welcomeMessage.to;
                let subject = welcomeMessage.subject;
                let body = welcomeMessage.body;
                return new Promise(function (resolve, reject) {
                    mailer.sendEmail(to, subject, body, {}, '', html);
                    resolve();
                });
            }

            if (welcomeMessage.type === "Video") {
                return self.sendVideo({url: welcomeMessage.url});
            }

            if (welcomeMessage.type === "Cards") {
                if (msg) {
                    welcomeMessage.cards[0].text = msg;
                }
                return self.sendCards(welcomeMessage.cards, paramOptions);
            }
            return;
        }

        if (mapping.welcomeOptions && mapping.welcomeOptions.options) {
            let options = _.map(mapping.welcomeOptions.options, (o) => {
                o.title = o.label;
                o.text = o.value;
                return o;
            });
            return self.sendQuickReplies({title: message, options: options}, paramOptions)
        } else {
            return self.sendTextMessage(message, paramOptions);
        }
    };


    self.sendVoice = function (text) {
        if (res) {
            res.json({
                message: text
            });

            metrics.increment("events.messages.count", {
                "user": bot,
                "source": "voice",
                "type": "sent",
                "uid": sender,
                "message": self.data.message || ""
            });

            vault.createMessage({
                from: bot,
                to: sender,
                reqPayload: text,
                bot: 'voice',
            });
        }
    };

    self.sendCard = function (card, options) {
        return new Promise(function (resolve) {
            card.conversationId = googleConversationId;
            if (!options) {
                options = {};
            }
            if (options.shouldEndSession) {
                card.shouldEndSession = options.shouldEndSession;
            }
            if (source === 'googleAssistant') {
                messageArray.push(card);
                return resolve();
            } else {
                resolve();
            }


        });
    };
    self.sendCards = function (cards, hideInput, options) {
        return new Promise(function (resolve, reject) {
            let obj = {cards: cards};
            if (!runDefaultFunction) {
                vault.createMessage(self.sender, source, self.bot, sessionId, JSON.stringify(obj), sessionObject, receivedMessageTime, self.messageId(), self.orchestratorBotId);
            }

            if (source === "yellowmessenger") {
                obj.hideInput = hideInput;
            }

            if (source === "alexa") {
                if (options && options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                return sendMessage(obj, res, bot, sender, () => {
                    resolve();
                });
            }

            if (source === "googleAssistant") {
                obj.conversationId = googleConversationId;
                if (options && options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                if (options && options.suggestions) {
                    obj.suggestions = options.suggestions;
                }
            }

            if (source === "kookoo") {
                return sendMessage(obj, res, bot, sender, sid, () => {
                    resolve();
                })
            }

            if (((options && options.target_language) || (self.options && self.options.targetLanguage && self.options.targetLanguage !== 'en')) && !self.options.i18n) {
                let language = options && options.target_language ? options.target_language : self.options.targetLanguage;
                let messages = [];
                messages = messages.concat(_.map(cards, function (option) {
                    return option.title;
                }));
                translateClient.translate(messages, language, (err, translation) => {
                    if (cards.length === 1) {
                        cards[0].title = translation;
                    } else {
                        cards = _.map(cards, function (option, i) {
                            option.title = translation[i];
                            return option;
                        });
                    }
                    obj['cards'] = cards;
                    if (source === 'yellowmessenger') {
                        obj = _.assign(obj, self.xmppObj);
                        if (runDefaultFunction) {
                            messageArray.push(obj);
                            return resolve();
                        }
                        else {
                            return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                                return resolve();
                            })
                        }

                    }

                    else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                        return sendResponse(bot, sender, source, obj, mapping).then(() => {
                            return resolve();
                        });
                    }
                    else if (source === 'alexa' || source === 'googleAssistant') {
                        messageArray.push(obj);
                        return resolve();
                    }
                });
            } else {
                if (source === 'yellowmessenger') {
                    obj = _.assign(obj, self.xmppObj);
                    if (runDefaultFunction) {
                        messageArray.push(obj);
                        return resolve();
                    }
                    else {
                        return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                            return resolve();
                        })
                    }
                } else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                    return sendResponse(bot, sender, source, obj, mapping).then(() => {
                        return resolve();
                    });
                } else if (source === 'alexa' || source === 'googleAssistant') {
                    messageArray.push(obj);
                    return resolve();
                }
            }
        });
    };

    // TODO Send multiple messages
    self.sendMessagesFromArr = (arr, callback) => {
        if (arr.length > 0) {
            let message = arr.shift();

            if (arr.length > 0) {
                sendMessage(sender, {message: message}, bot, function () {
                    self.sendMessagesFromArr(arr, callback);
                });
            } else {
                sendMessage(sender, {message: message}, bot, () => {
                    if (callback) callback();
                });
            }
        }
    };
    self.sendResponseToUser = (sender, obj, extraParams) => {
        // return getContextOfOtherUser(bot,sender).then(context => {
        //     // if(context.complete || context.complete === undefined) {
        //     //     return sendResponse(bot, sender, source, {quickReplies: obj}, mapping);
        //     // }
        //     // return Promise.resolve();
        //     return sendResponse(bot, sender, source, {quickReplies: obj}, mapping);
        // }).then(() => {
        //     return Promise.resolve();
        // });

        if (source === 'botframework') {
            const userMapping = _.cloneDeep(mapping);
            userMapping.serviceUrl = extraParams.serviceUrl;
            const messageType = extraParams.messageType || 'message';
            const data = {};
            data[messageType] = obj;
            return sendResponse(bot, sender, source, data, userMapping);
        } else {
            const messageType = extraParams.messageType || 'message';
            const data = {};
            data[messageType] = obj;
            return sendResponse(bot, sender, source, data);
        }
    };

    self.sendAdaptiveCard = function (adaptiveCard) {
        return new Promise((resolve, reject) => {
            if (source === 'botframework') {
                if (typeof adaptiveCard !== 'object') {
                    return reject("Adaptive Card has to be an Object");
                }
                let obj = {
                    adaptiveCard: adaptiveCard
                };
                return sendResponse(bot, sender, source, obj, mapping).then(() => {
                    return resolve();
                });
            } else {
                return reject("Not Supported");
            }
        });
    };

    self.sendFlightDetails = function (data, options) {
        return new Promise(function (resolve, reject) {
            if (source === 'yellowmessenger') {
                let obj = {flightDetails: data};
                obj = _.assign(obj, self.xmppObj);
                if (runDefaultFunction) {
                    messageArray.push(obj);
                    return resolve();
                }
                else {
                    return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                        return resolve();
                    })
                }
            }
        });
    };

    self.sendBoardingPasses = function (data, options) {
        return new Promise(function (resolve, reject) {
            if (source === 'yellowmessenger') {
                let obj = {boardingPasses: data};
                obj = _.assign(obj, self.xmppObj);
                if (runDefaultFunction) {
                    messageArray.push(obj);
                    return resolve();
                }
                else {
                    return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                        return resolve();
                    })
                }
            }
        });
    };

    self.sendWebViews = function (data, options) {
        return new Promise(function (resolve, reject) {
            if (source === 'yellowmessenger') {
                let obj = {webViews: data};
                obj = _.assign(obj, self.xmppObj);
                if (runDefaultFunction) {
                    messageArray.push(obj);
                    return resolve();
                }
                else {
                    return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                        return resolve();
                    })
                }
            }
        });
    };

    self.sendTextMessage = function (message, options) {
        return new Promise(function (resolve, reject) {
            if (!message) {
                message = "Empty message";
            }

            let messages = message.split("::");
            message = messages[(parseInt(Math.random() * 1000) % messages.length)];
            let obj = {message: message};
            if (!runDefaultFunction) {
                vault.createMessage(self.sender, source, self.bot, sessionId, JSON.stringify(obj), sessionObject, receivedMessageTime, self.messageId(), self.orchestratorBotId);
            }

            if (source === "yellowmessenger") {
                if (!options) {
                    options = {};
                }
                obj.hideInput = options.hideInput;
                obj.keyboardType = options.keyboardType;
                obj.update = options.update;
            }

            if (source === "twilio") {
                if (!options) {
                    options = {};
                }
                if (options.saveMessage) {
                    self.memory.set("saveMessage", message);
                    resolve();
                } else {
                    twilio.sendMessage(obj, res, bot, sender, () => {
                        resolve()
                    });
                }
                return;
            }
            if (source === "alexa") {
                if (!options) {
                    options = {};
                }
                if (options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                if (options.audio) {
                    obj.audio = options.audio;
                }
                if (options.card) {
                    obj.alexaCard = options.card;
                }
                if (options.saveMessage) {
                    self.memory.set("saveMessage", message);
                    resolve();
                } else {
                    sendMessage(obj, res, bot, sender, () => {
                        resolve();
                    });
                }
                return;
            }

            if (source === "slack") {
                obj.channel = slackChannel;
                obj.token = slackToken;
                axiosInstance.post('/slack/send', {
                    data: {
                        message: obj,
                        options: options,
                        bot: bot,
                        sender: sender
                    }
                }).then(function (response) {
                    return resolve();
                })
                    .catch(function (error) {
                        return reject();
                    });
            }

            if (source === "kookoo") {
                return sendMessage(obj, res, bot, sender, sid, () => {
                    resolve();
                });
            }

            if (source === "googleAssistant") {
                if (!options) {
                    options = {};
                }
                obj.conversationId = googleConversationId;
                if (options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                if (options.requestLocation) {
                    obj.requestLocation = options.requestLocation;
                }
                obj.optContext = "";
                if (options.optContext) {
                    obj.optContext = options.optContext;
                }
                if (options.audio) {
                    obj.audio = options.audio;
                }
                if (options.speechMessage) {
                    obj.speechMessage = options.speechMessage
                }
                if (options.auth) {
                    obj.auth = options.auth;
                }
            }

            if (((options && options.target_language) || (self.options && self.options.targetLanguage && self.options.targetLanguage !== 'en')) && !self.options.i18n) {
                let language = options && options.target_language ? options.target_language : self.options.targetLanguage;
                translateClient.translate(message, language, (err, translation) => {
                    obj.message = translation;
                    if (source === 'yellowmessenger') {
                        obj = _.assign(obj, self.xmppObj);
                        if (runDefaultFunction) {
                            messageArray.push(obj);
                            return resolve();
                        }
                        else {
                            return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                                return resolve();
                            })
                        }

                    }
                    else if (source === 'sms') {
                        return sendResponse(bot, sender, source, obj, mapping).then(() => {
                            return resolve();
                        });
                    }
                    else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                        return sendResponse(bot, sender, source, obj, mapping).then(() => {
                            return resolve();
                        });
                    }
                    else if (source === 'alexa' || source === 'googleAssistant') {
                        messageArray.push(obj);
                        return resolve();
                    } else if (source === "voice") {
                        obj.lang = language;
                        messageArray.push(obj);
                        return resolve();
                    }

                });
            } else {
                if (source === 'yellowmessenger') {
                    obj = _.assign(obj, self.xmppObj);
                    if (runDefaultFunction) {
                        messageArray.push(obj);
                        return resolve();
                    }
                    else {
                        return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                            return resolve();
                        })
                    }

                }
                if (source === 'sms') {
                    return sendResponse(bot, sender, source, obj, mapping).then(() => {
                        return resolve();
                    });
                }
                else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                    if (options && options.uid) {
                        return sendResponse(bot, options.uid, source, obj, mapping).then(() => {
                            return resolve();
                        });
                    } else {
                        return sendResponse(bot, sender, source, obj, mapping).then(() => {
                            return resolve();
                        });
                    }
                }
                else if (source === 'alexa' || source === 'googleAssistant') {
                    messageArray.push(obj);
                    return resolve();
                } else if (source === "voice") {
                    obj.lang = self.options.targetLanguage;
                    messageArray.push(obj);
                    return resolve();
                }
            }
        });
    };

    self.sendTyping = function () {
        return new Promise(function (resolve, reject) {
            if (source === 'yellowmessenger') {
                sendTyping(bot, sender).then((res) => {
                    resolve();
                });
            } else {
                resolve();
            }
        });
    };

    self.sendWebView = function (title, url, height, options) {
        return new Promise(function (resolve) {
            let obj = {
                webView: {
                    title: title,
                    url: url,
                    height: height || 250
                }
            };
            if (options && options.hideInput) {
                obj.hideInput = true;
            }
            if (source === 'yellowmessenger') {
                if (runDefaultFunction) {
                    messageArray.push(obj);
                    return resolve();
                }
                else {
                    return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                        return resolve();
                    })
                }

            }
            else {
                return resolve();
            }

        });
    };

    self.sendQuickReplies = function (quickReplies, options) {
        return new Promise(function (resolve, reject) {

            if (!quickReplies) {
                return reject();
            }
            let messages = quickReplies.title.split("::");
            quickReplies.title = messages[(parseInt(Math.random() * 1000) % messages.length)];

            let obj = {quickReplies: quickReplies};
            if (!runDefaultFunction) {
                vault.createMessage(self.sender, source, self.bot, sessionId, JSON.stringify(obj), sessionObject, receivedMessageTime, self.messageId(), self.orchestratorBotId);
            }

            if (source === "yellowmessenger") {
                if (!options) {
                    options = {};
                }
                obj.hideInput = options.hideInput;
                obj.keyboardType = options.keyboardType;
                obj.update = options.update;
            }
            if (source.toLowerCase() === 'facebook') {
                quickReplies.options = _.map(quickReplies.options, option => {
                    if (option.facebookTitle && option.facebookTitle.length > 0) {
                        option.title = option.facebookTitle
                    }
                    return option
                });
            }
            if (source === "alexa") {
                if (options && options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                return sendMessage(obj, res, bot, sender, () => {
                    resolve();
                });
            }

            if (source === "slack") {
                obj.channel = slackChannel;
                obj.token = slackToken;
                axiosInstance.post('/slack/send', {
                    data: {
                        quickReplies: obj,
                        options: options,
                        bot: bot,
                        sender: sender
                    }
                }).then(function (response) {
                    return resolve();
                })
                    .catch(function (error) {
                        return reject();
                    });
            }

            if (source === "googleAssistant") {
                if (!options) {
                    options = {};
                }
                obj.conversationId = googleConversationId;
                if (options.shouldEndSession) {
                    obj.shouldEndSession = options.shouldEndSession;
                }
                if (options.speechMessage) {
                    obj.speechMessage = options.speechMessage;
                }

                if (options.requestLocation) {
                    obj.requestLocation = options.requestLocation;
                }
                obj.conversationId = googleConversationId;
            }

            if (source === "kookoo") {
                return sendMessage(obj, res, bot, sender, sid, () => {
                    resolve();
                })
            }

            if (((options && options.target_language) || (self.options && self.options.targetLanguage && self.options.targetLanguage !== 'en')) && !self.options.i18n) {
                let language = options && options.target_language ? options.target_language : self.options.targetLanguage;
                let messages = [];
                messages.push(quickReplies.title);
                quickReplies.options.forEach((option) => {
                    messages.push(option.title);
                });
                translateClient.translate(messages, language, (err, translation) => {
                    quickReplies.title = translation[0];
                    quickReplies.options = _.map(quickReplies.options, (option, i) => {
                        if (translation[i + 1] && translation[i + 1].length > 0) {
                            option.title = translation[i + 1];
                        }
                        return option;
                    });

                    if (source === 'kookoo') {
                        return sendMessage({quick_replies: quickReplies}, res, bot, sender, sid, self.options.kookoo_language, () => {
                            resolve();
                        });
                    }

                    if (source === 'voice') {
                        obj.message = translation;
                        return sendMessage(obj, res, bot, sender, () => {
                            resolve();
                        });
                    }
                    if (source === 'yellowmessenger') {
                        obj = _.assign(obj, self.xmppObj);
                        if (runDefaultFunction) {
                            messageArray.push({quickReplies: quickReplies, ...obj});
                            return resolve();
                        }
                        else {
                            return sendResponse(bot, sender, 'yellowmessenger', {quickReplies: quickReplies, ...obj}).then(() => {
                                return resolve();
                            })
                        }
                    }

                    else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                        return sendResponse(bot, sender, source, {quickReplies: quickReplies}, mapping).then(() => {
                            return resolve();
                        });
                    }
                    else if (source === 'alexa' || source === 'googleAssistant') {
                        messageArray.push({quickReplies: quickReplies});
                        return resolve();
                    }

                });

            }
            else {
                if (source === 'yellowmessenger') {
                    obj = _.assign(obj, self.xmppObj);
                    if (runDefaultFunction) {
                        messageArray.push(obj);
                        return resolve();
                    }
                    else {
                        return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                            return resolve();
                        })
                    }
                }

                else if (source === 'facebook' || source === 'botframework' || source === 'skype') {
                    return sendResponse(bot, sender, source, obj, mapping).then(() => {
                        return resolve();
                    });
                }
                else if (source === 'alexa' || source === 'googleAssistant') {
                    messageArray.push(obj);
                    return resolve();
                }
            }


        })

    };

    self.sendSelection = function (selection, options) {
        return new Promise(function (resolve, reject) {
            let obj = {selection: selection};
            if (source === "yellowmessenger") {
                if (!options) {
                    options = {};
                }
                obj.hideInput = options.hideInput;
                obj.keyboardType = options.keyboardType;
                obj.update = options.update;
                if (source === 'yellowmessenger') {
                    return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                        return resolve();
                    })
                }
            }

        });
    };

    self.sendEvent = function (event, options) {
        return new Promise(function (resolve, reject) {
            if (source === 'yellowmessenger') {
                return sendResponse(bot, sender, 'yellowmessenger', {event: event}).then(() => {
                    return resolve();
                })
            }
        });
    };

    let sendImagesInternal = function (imagesArr, n) {
        if (n < imagesArr.length) {
            return self.sendImage(imagesArr[n])
                .then(function () {
                    return sendImagesInternal(imagesArr, n + 1)
                });
        } else {
            return Promise.resolve();
        }
    };

    let sendMessagesInternal = function (messageArr, n) {
        if (n < messageArr.length) {
            return self.sendTextMessage(messageArr[n])
                .then(function () {
                    return sendMessagesInternal(messageArr, n + 1)
                });
        } else {
            return Promise.resolve();
        }
    };

    // Send Multiple Images at once to the user with order being maintained
    self.sendMultipleImages = function (imageArr) {
        return new Promise(resolve => {
            sendImagesInternal(imageArr, 0).then(() => {
                return resolve();
            });
        });
    };

    //Uploading a file to the blob and getting the signed URL
    self.uploadFile = function (buffer, fileName, expiryTime) {
        return new Promise(resolve => {
            createSasUrl(buffer, fileName, expiryTime).then(url => {
                return resolve(url);
            }).catch(err => {
                return resolve(err);
            })
        })
    };

    self.sendMultipleTextMessages = function (messageArr, options) {
        return new Promise(resolve => {
            if (options && options.random) {
                let messageIndex = 0;
                if (messageArr && messageArr.length > 0) {
                    messageIndex = Math.floor(Math.random() * Math.floor(messageArr.length));
                }
                sendMessagesInternal(messageArr, 0).then(() => {
                    return resolve();
                });


            } else {
                sendMessagesInternal(messageArr, 0).then(() => {
                    return resolve();
                });

            }

        });
    };

    self.sendImage = function (image) {
        return new Promise(function (resolve, reject) {
            let obj = {
                image: image
            };
            if (runDefaultFunction) {
                messageArray.push(obj);
                return resolve();
            } else {
                return sendResponse(bot, sender, 'yellowmessenger', obj).then(() => {
                    return resolve();
                })
            }

        });
    };

    self.sendAirlineItinerary = function (airlineIter) {
        return new Promise((resolve, reject) => {

            if (source === 'facebook') {
                return sendResponse(bot, sender, 'facebook', {airline_itinerary: airlineIter}).then(() => {
                    return resolve();
                });
            }
            else {
                return reject();
            }

        });
    };

    self.sendGoogleImageTracker = function (imageUrl) {
        return new Promise((resolve) => {
            if (source === 'yellowmessenger') {
                return sendResponse(bot, sender, 'yellowmessenger', {googleTracker: {img: imageUrl}}).then(() => {
                    return resolve();
                })
            }

        })
    };

    /*
     Parameter - {url : 'URL_TO_THE_VIDEO'} or {attachment_id: 'Attachment ID'}
     Attachment ID paramter only works for Facebook Messenger and will be discarded
     for all other platforms.
     */
    self.sendVideo = function (video) {
        return new Promise((resolve, reject) => {
            if (video.url) {
                if (source === 'yellowmessenger') {
                    return sendResponse(bot, sender, 'yellowmessenger', {video: video}).then(() => {
                        return resolve();
                    })
                }

            } else if (video.attachment_id && source === 'facebook') {
                if (source === 'facebook') {
                    return sendResponse(bot, sender, 'facebook', {video: video}).then(() => {
                        return resolve();
                    });
                }

            } else {
                reject({message: 'Invalid Attachment. Message not sent.'});
            }
        });
    };
    // Feedback Related
    self.feedbackEvent = {
        feedbackProvided: function () {
            if (self.data.event && self.data.event === 'feedback-event') {
                return {
                    event: self.data.event,
                    data: self.data.data
                }
            } else {
                return false;
            }
        }
    };


    self.successFactors = {
        getUser: (userId) => {
            return new Promise(function (resolve, reject) {
                if (mapping && mapping.auth && mapping.auth.successFactors && mapping.auth.successFactors.username){
                    let url = `https://api8.successfactors.com/odata/v2/User('${userId}')?$select=payGrade,userId,division,location,firstName,lastName,email,username,addressLine1,department,custom07,division,location,gender,status,city,state,zipCode,custom01,jobCode,manager/userId,manager/username,incumbentOfPositionNav/payGradeNav/name&$expand=manager,empInfo/jobInfoNav,empInfo,incumbentOfPositionNav/payGradeNav&$format=json`;
                    let options = {
                        method: 'GET',
                        url: url,
                        headers: {
                            'cache-control': 'no-cache',
                            'content-type': 'application/json',
                            authorization: "Basic " + (new Buffer(mapping.auth.successFactors.username + ":" + mapping.auth.successFactors.password).toString('base64'))
                        },
                        json: true
                    };

                    request(options, function (error, response, dataBody) {
                        if (error || dataBody.error || !dataBody.d) {
                            reject(dataBody && dataBody.error ? dataBody.error.message : "error");
                        } else {
                            resolve(dataBody.d);
                        }
                    });
                } else{
                    reject("authorization token unavailable");
                }
            });
        }
    };

    self.geoCode = geoUtil.geoCode;
    self.reverseGeoCode = geoUtil.reverseGeoCode;
    self.showTimesApi = gruvi.showTimesApi;


    self.azure = {
        auth: function () {
            let stateParams = encodeURIComponent(new Buffer(JSON.stringify({
                bot: bot,
                source: source,
                sender: sender
            })).toString('base64'));
            return `https://login.microsoftonline.com/${mapping.auth.azure.tenant_id}/oauth2/${mapping.auth.azure.version
                ? mapping.auth.azure.version + '/' : ''}authorize?client_id=${mapping.auth.azure.client_id}&response_type=code&redirect_uri=${bpConfig.urls.AZURE_URL_REDIRECT}
            &response_mode=query&state=${stateParams}${mapping.auth.azure.domain_hint ? '&domain_hint=' + mapping.auth.azure.domain_hint : ''}${mapping.auth.azure.scope ? '&scope=' + mapping.auth.azure.scope : ''}`;
        },
        authReceived: function () {
            return self.data.event && self.data.event === 'azure-auth-success';
        },
        user: function (accessToken) {
            return new Promise(function (resolve, reject) {
                let options = {
                    method: 'GET',
                    url: 'https://graph.windows.net/me',
                    qs: {'api-version': '1.6'},
                    headers: {
                        'cache-control': 'no-cache',
                        'content-type': 'application/json',
                        authorization: 'Bearer ' + accessToken
                    },
                    json: true
                };

                request(options, function (error, response, dataBody) {
                    if (error || dataBody['odata.error']) {
                        reject('error');
                    } else {
                        resolve(dataBody);
                    }
                });
            });
        }
    };
};

let clearContextWithOrchestrator = function (bot, uid, triggerBot) {
    return new Promise((resolve) => {
        let app = new App({
            sender: uid,
            bot: bot,
            botIdentifier: bot,
            profile: {},
            source: 'yellowmessenger',
            data: {
                message: ''
            }
        });
        let clearContext = () => {
            app.getContext().then(function () {
                app.clearContext();
            });
        };
        app.orchestrator.getContext().then(() => {
            // clearing the childbots context
            if (app.orchestrator.context && app.orchestrator.context.current) {
                app.orchestrator.clearChildBotsContext(app.orchestrator.context.current).then(() => {
                    if (triggerBot) {
                        app.orchestrator.clearChildBotsContext(triggerBot).then(() => {
                            app.orchestrator.setBot(triggerBot);
                            clearContext();
                            resolve();
                        });

                    } else {
                        clearContext();
                        resolve();
                    }
                });
            } else {
                clearContext();
                resolve();
            }
        });
    });
};

module.exports = {
    App,
    clearContextWithOrchestrator
};
