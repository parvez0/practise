'use strict';
// Imports
const
    request = require('request'),
    _ = require('lodash'),
    tag = "KNOWLEDGE",
    bingTranslateApiAccessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzY29wZSI6Imh0dHBzOi8vYXBpLm1pY3Jvc29mdHRyYW5zbGF0b3IuY29tLyIsInN1YnNjcmlwdGlvbi1pZCI6IjUyYTkxNzg5YzgxNDQzY2FiMTMzOTQwMDM4MjQ2OWU1IiwicHJvZHVjdC1pZCI6IlRleHRUcmFuc2xhdG9yLlMxIiwiY29nbml0aXZlLXNlcnZpY2VzLWVuZHBvaW50IjoiaHR0cHM6Ly9hcGkuY29nbml0aXZlLm1pY3Jvc29mdC5jb20vaW50ZXJuYWwvdjEuMC8iLCJhenVyZS1yZXNvdXJjZS1pZCI6Ii9zdWJzY3JpcHRpb25zLzIyZGI2MTQyLTVjMzItNGJkNC05MmM5LTQ0NWFlNWUyNzQxNS9yZXNvdXJjZUdyb3Vwcy9jb2duaXRpdmUtYXBwcy9wcm92aWRlcnMvTWljcm9zb2Z0LkNvZ25pdGl2ZVNlcnZpY2VzL2FjY291bnRzL3RyYW5zbGF0b3IiLCJpc3MiOiJ1cm46bXMuY29nbml0aXZlc2VydmljZXMiLCJhdWQiOiJ1cm46bXMubWljcm9zb2Z0dHJhbnNsYXRvciIsImV4cCI6MTQ3OTE1MDUyMH0.c60i0yOfDJOYGhmHb0TXOc9K_G2K7jGhcWqFCRExLl0";

request.defaults({
    timeout: 1000,
    pool: {maxSockets: 5000},
});


function stripHTML(message){
    return message.replace(/<\/?[^>]+(>|$)/g, "");
}

// Maps
let bingWebsiteToIntentMap = {
    "www.imdb.com":"movies_bot",
    "in.bookmyshow.com":"movies_bot",
    "www.bookmyshow.com":"movies_bot",
    "flickstime.com":"movies_bot",
    "www.filmipop.com":"movies_bot",
    "www.fandango.com":"movies_bot",

    // Fashion
    "www.zappos.com":"fashion_bot",
    "www.myntra.com":"fashion_bot",
    "shop.mango.com":"fashion_bot",
    "www1.macys.com":"fashion_bot",

    // Electronics
    "gadgets.ndtv.com":"electronics_bot",
    "www.apple.com":"electronics_bot",
    "www.att.com":"electronics_bot",
    "www.sony.com":"electronics_bot",
    "myxperia.sonymobile.com":"electronics_bot",
    "www.gsmarena.com":"electronics_bot",
    "www.mi.com":"electronics_bot",
    "www.oppo.com":"electronics_bot"
};

// Maps
let bingWebsiteEntities = {
    "movies_bot": function(page,message){
        return new Promise(function(resolve){
            let entities = {};
            let website = hostNameFromUrl(stripHTML(page.displayUrl));
            if(website === "www.imdb.com"  && stripHTML(page.displayUrl).startsWith("www.imdb.com/title")){
                entities.movie_name = stripHTML(page.name).replace(/<\/?[^>]+(>|$)/g, "").replace("- IMDb","").replace(/\(.*?\)/,"").trim();
            }
            if(website === "www.fandango.com"  && _.endsWith(stripHTML(page.displayUrl),"/movieoverview")){
                entities.movie_name = stripHTML(page.name).replace(/<\/?[^>]+(>|$)/g, "").replace("| Fandango","").replace(/\(.*?\)/,"").trim();
            }
            resolve(entities);
        });
    }
};

let bingKeywordToIntentMap = {
    // Fashion related keywords
    "shoes":"fashion_bot",
    "shoe":"fashion_bot",
    "clothes":"fashion_bot",
    "fashion":"fashion_bot",
    "shorts":"fashion_bot",
    "shirts":"fashion_bot",
    "sarees":"fashion_bot",
    "jeans":"fashion_bot",
    "watches":"fashion_bot",
    "watch":"fashion_bot",
    "jewelery":"fashion_bot",
    "shirt":"fashion_bot",
    "tee":"fashion_bot",
    "tees":"fashion_bot",
    "t-shirts":"fashion_bot",
    "t-shirt":"fashion_bot",
    "tshirt":"fashion_bot",

    // Movies
    "actor":"movies_bot",
    "filmography":"movies_bot",
    "movie":"movies_bot",

    // Cabs


    // Recharge

    // Electronics
    "smartphones":"electronics_bot",
    "phone":"electronics_bot",
    "samsung":"electronics_bot",
    "apple":"electronics_bot"
};

/*

1. Finding the intent of a message
2. Check if there is any trained intent for this message
3. If yes return
4. Else Check with bing
5. If intent is identified by bing search then return
6. Else ask the user to train it

 */

let nlpIntent = function (message){
    return new Promise(function (resolve, reject){
        request.get({
            'url': 'https://api.wit.ai/message?q='+message,
            'headers': {
                'Authorization': 'Bearer W2KYKWOKSS246W5AWOLSCN2SVSA3IQ6W'
            }
        }, function (err, response) {
            if(!err){
                // Parse the body
                response = JSON.parse(response.body);
                if(response && response.entities && response.entities.intent &&
                    response.entities.intent.length > 0){
                    if (resolve) resolve(response.entities.intent[0].value);
                }else{
                    reject();
                }
            }else{
                reject();
            }
        });
    });
};

let bingIntent = function (message){
    return new Promise(function (resolve, reject){
        request.get({
            'url': 'https://api.cognitive.microsoft.com/bing/v5.0/search?q='+message+'&count=10&offset=0&mkt=en-us&safesearch=Moderate',
            'headers': {
                'Ocp-Apim-Subscription-Key': '2fae51e4cfde4532bf2eaa242e15c6f6'
            }
        }, function (err, response) {
            if(!err){
                try{
                    // Parse the body
                    response = JSON.parse(response.body);

                    let pages = response.webPages.value;

                    let intent = null;

                    pages.every(function(page,pageIdx){
                        let website = hostNameFromUrl(stripHTML(page.displayUrl));
                        intent = bingWebsiteToIntentMap[website];
                        if(intent){
                            return false;
                        }else{
                            let keywords = page.name.split(" ");
                            // keywords = keywords.concat(page.snippet.split(" "));
                            keywords.every(function(keyword,keywordIdx){
                                keyword = keyword.replace(/[,\.]/g,'');
                                intent = bingKeywordToIntentMap[keyword.toLowerCase()];
                                return !intent;
                            });
                            return !intent;
                        }
                    });

                    // If intent identified
                    if(intent){
                        if (resolve) resolve(intent);
                        // TODO Train wit
                        // trainWit(intent,message);
                    }else{
                        reject();
                    }
                }catch(e){
                    reject();
                }
            }else{
                reject();
            }
        });
    });
};



let findIntent = function(message){
    return new Promise(function(resolve,reject){
        // NLP Intent
        nlpIntent(message).then(function(intent){
            if(intent){
                 resolve(intent);
            }else{
                bingIntent(message).then(function(intent){
                     resolve(intent);
                },function(){
                     reject();
                });
            }
        },
        // Bing Intent
        function(){

            bingIntent(message).then(function(intent){
                 resolve(intent);
            },function(){
                 reject();
            });
        });
    });
};

let trainWit = function(intent,message){
    return new Promise(function (resolve, reject) {
        request.post({
            'url': 'https://api.wit.ai/entities/intent/values',
            'headers': {
                'Authorization': 'Bearer ONRC7QEY25D44YGBAVLDZSC5MWTGPAT4'
            },
            'json' : {
                value:intent,
                expressions:[message],
                metadata:''
            }
        }, function (err, response) {
            if(!err){
                if (resolve) resolve(response.body);
            }else{
                reject();
            }
        });
    });
};

let bingIntelligence = function(message){
    return new Promise(function (resolve, reject){
        request.get({
            'url': 'https://api.cognitive.microsoft.com/bing/v5.0/search?q='+message+'&count=10&offset=0&mkt=en-us&safesearch=Moderate',
            'headers': {
                'Ocp-Apim-Subscription-Key': '2fae51e4cfde4532bf2eaa242e15c6f6'
            }
        }, function (err, response) {
            if(!err){
                try{
                    // Parse the body
                    response = JSON.parse(response.body);
                    let pages = response.webPages.value;
                    let intent = null;
                    let identifiedPage = null;

                    pages.every(function(page,pageIdx){
                        let website = hostNameFromUrl(stripHTML(page.displayUrl));
                        intent = bingWebsiteToIntentMap[website];
                        identifiedPage = page;
                        return !intent && pageIdx<4;
                    });

                    // If intent identified
                    if(intent){
                        let data = {intent:intent};
                        if(bingWebsiteEntities[intent]){
                            bingWebsiteEntities[intent](identifiedPage,message).then(function(entities){
                                data.entities = entities;
                                resolve(data);
                            });
                        }else{
                            resolve(data);
                        }
                    }else{
                        reject();
                    }
                }catch(e){
                    reject();
                }
            }else{
                reject();
            }
        });
    });
};

let hostNameFromUrl = function(url) {
    let domain;
    //find & remove protocol (http, ftp, etc.) and get domain
    if (url.indexOf("://") > -1) {
        domain = url.split('/')[2];
    }
    else {
        domain = url.split('/')[0];
    }
    //find & remove port number
    domain = domain.split(':')[0];
    return domain;
};

let brandTags = ["NNS","NN","JJS","JJ","FW","NNP","NNPS","JJR"];
let askEniac = function(message) {
    return new Promise(function (resolve, reject) {
        if(!message || message.trim()===""){
            reject();
            return;
        }
        request.get({
            'url': 'http://eniac:8080/nlp/' + message
        }, function (err, response,body) {
            if (!err) {
                try{
                    let resp = JSON.parse(body);
                    let words = "";
                    for(let i in resp.posTags){
                        if(brandTags.indexOf(resp.posTags[i]) !== -1){
                            words += resp.tokens[i]+" ";
                        }
                    }
                    if(words.trim() !== ""){
                        if (resolve) resolve(words);
                    }else{
                        reject();
                    }
                }catch(e) {
                    reject();
                }
            } else {
                reject();
            }
        });
    });
};

let spellCheck = function (message) {
    return new Promise(function (resolve, reject) {
        var options = {
            method: 'POST',
            url: 'https://api.cognitive.microsoft.com/bing/v7.0/spellcheck',
            qs: {mode: 'spell'},
            headers:
                {
                    'ocp-apim-subscription-key': '5aacb252a530441a9bd9881f450459b9',
                    'content-type': 'application/x-www-form-urlencoded'
                },
            form: {Text: message}
        };

        request(options, function (error, response, body) {
            try {
                body = JSON.parse(body);
            } catch (e) {
                // Do Nothing
                return resolve(message);
            }

            if (response.statusCode === 200 || response.statusCode === '200') {
                if (body && body.flaggedTokens && body.flaggedTokens.length > 0) {
                    if (!error) {
                        // flagged tokens
                        if (body.flaggedTokens) {
                            for (let i = 0; i < body.flaggedTokens.length; i++) {
                                message = message.replace(body.flaggedTokens[i].token, body.flaggedTokens[i].suggestions[0].suggestion);
                            }
                        }

                        return resolve(message);
                    } else {
                        return resolve(message);
                    }
                } else {
                    return resolve(message);
                }
            } else {
                return resolve(message);
            }
        });
    });
};


module.exports = {
    findIntent:findIntent,
    askEniac:askEniac,
    bingIntelligence:bingIntelligence,
    spellCheck:spellCheck
};
