'use strict';
const axios = require('axios');
const config = require('../config');
const dataURL = config.urls.DATA_SERVICE;
const axiosInstance = axios.create({
    baseURL: dataURL
});

const axiosDataWrapper = (data, serviceName) => {
    return axiosInstance({
        method: 'post',
        url: `/internal/rabbit/${serviceName}`,
        data
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    });
};
module.exports = {
    publish : function(data,queue, callback){
        let requestData = {
            data,
            queue
        };
        axiosDataWrapper(requestData, 'publish').then(callback).then(callback, callback);
    }
};
