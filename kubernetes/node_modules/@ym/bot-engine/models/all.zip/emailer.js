'use strict';
let variableConfig = require('../config.js');
let helper = require('sendgrid').mail;
let sg = require('sendgrid')(variableConfig.sendgrid_key);

let sendEmailBeta = function(email){
    return new Promise(function(resolve,reject){
        let from_email = new helper.Email(email.from ||'noreply@mailer.botplatform.io');

        let content = new helper.Content(email.text?'text/plain':'text/html', email.text||email.html);
        let mail = new helper.Mail();


        mail.setFrom(from_email);
        mail.addContent(content);
        mail.setSubject(email.subject);
        let personalization = new helper.Personalization();

        if(email.to instanceof Array){
            for(let i = 0 ; i < email.to.length; i++){
                personalization.addTo(new helper.Email(email.to[i].trim()));
            }
        }else{
            personalization.addTo(new helper.Email(email.to));
        }

        mail.addPersonalization(personalization);


        if(email.attachments && email.attachments.length>0){
            for(let i = 0; i < email.attachments.length; i++){
                let attachment = new helper.Attachment();
                attachment.setFilename(email.attachments[i].filename);
                attachment.setContent(new Buffer(email.attachments[i].data).toString('base64'));
                mail.addAttachment(attachment);
            }
        }

        let request = sg.emptyRequest({
            method: 'POST',
            path: '/v3/mail/send',
            body: mail.toJSON(),
        });

        sg.API(request, function(error, response) {
            if(resolve)resolve();
        });
    });
};

let sendEmail = function(to,subject,body,attachments,from, html){
    return sendEmailBeta({
        to : to,
        from: from,
        subject: subject,
        attachments: attachments,
        text: body,
        html: html
    });
};

module.exports = {
    sendEmail:sendEmail,
    sendEmailBeta: sendEmailBeta
};
