'use strict';
const rpcClient = require('./rpcClient');
const config = require('../config');
const axios = require('axios');
const axiosInstance = axios.create({
    baseURL: config.urls.AGENTS_SERVICE
});

const createTicket = (mapping, route, ticketData, manualAssignment, tags, offlineAssignment) => {
    return axiosInstance({
        method: 'post',
        url: '/agents/createTicket',
        data: {
            mapping,
            route,
            data: ticketData,
            manualAssignment,
            tags,
            offlineAssignment
        }
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    })
};

module.exports = {
    createTicket
};
