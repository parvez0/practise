/**
 * Created by sachin on 27 Apr 2018.
 */
const {Memory} = require('../memory');
const _ = require('lodash');

let Orchestrator = function (app, mapping) {
    let self = this;
    let profileOriginal = _.clone(app.profile, true);
    let sender = app.sender;
    let memoryInstance = new Memory(!app.orchestratorStarted && app.referrer ? app.referrer : app.bot, sender); // memory instance for common memory profile
    this.options = {
        askConfidence: 0.9,
        askConfidenceByBots: {},
        minConfidence: 0.7,
        searchedFilterConfidence: 0.6,
        secondaryChildBots: []
    };


    self.clearChildBotsContext = function (childBot) {
        return new Promise((resolve) => {
            if (childBot) {
                childMemoryObject = new Memory(childBot, sender);
                childMemoryObject.get("context").then((context) => {
                    context = JSON.parse(context);
                    if (!context.history) {
                        context.history = [];
                    }

                    if (context.intent) {
                        //if old bot is there entities is pushed otherwise steps are pushed .
                        if (context.steps || !context.entities) {
                            context.history.push({
                                intent: context.intent,
                                complete: context.complete,
                                steps: _.cloneDeep(context.steps)
                            });
                        } else {
                            context.history.push({
                                intent: context.intent,
                                complete: context.complete,
                                entities: _.cloneDeep(context.entities)
                            });
                        }
                        // Store only last 10 intents in the memory
                        context.history = context.history.splice(-1 * 5);
                    }
                    // Store the previous entities as well
                    delete context.paramExpected;
                    delete context.question;
                    delete context.options;
                    delete context.entities;
                    delete context.complete;
                    delete context.invalidCount;
                    delete context.intent;
                    delete context.journeyName;
                    delete context.stepId;
                    delete context.steps;

                    childMemoryObject.set("context", JSON.stringify(context)).then(() => {
                        resolve();
                    });

                }, () => {
                    resolve();
                })
            }
            else {
                resolve();
            }

        })
    };

    this.getBots = function (query, searchedFilterConfidence) {
        return new Promise(function (resolve) {
            if (query) {
                let functions = [];
                query.toLowerCase().split(' ').forEach((e) => {
                    functions.push({
                        "filter": {"match": {"keywords": e}},
                        "weight": 1
                    })
                });
                let searchBody = {
                    query: {
                        function_score: {
                            query: {
                                match: {
                                    keywords: query.toLowerCase()
                                }
                            },
                            "boost_mode": "replace",
                            "score_mode": "sum",
                            "functions": functions
                        }
                    },
                    highlight: {
                        fields: {
                            keywords: {}
                        }
                    }
                };
                app.dataStore.search({
                    table: "orchestrator",
                    body: searchBody
                }).then((results) => {
                    if (results.hits.total > 0) {
                        let allResults = _.map(results.hits.hits, function (hit) {
                            if (hit.highlight && hit.highlight.keywords) {
                                hit._source.highlightedKeyWords = hit.highlight.keywords;
                            }
                            return hit._source;
                        });
                        let filteredResults = [];
                        let filteredObject = [];
                        for (let i in allResults) {
                            for (let j = 0; j < allResults[i].highlightedKeyWords.length; j++) {
                                let keyword = allResults[i].highlightedKeyWords[j].replace(/<em>|<\/em>/gi, "");
                                let currentPercentage = (allResults[i].highlightedKeyWords[j].split('<em>').length - 1) / keyword.split(' ').length;
                                if (currentPercentage >= searchedFilterConfidence) {
                                    filteredResults.push(allResults[i]);
                                    filteredObject.push({
                                        percentage: currentPercentage,
                                        keyWordLength: keyword.split(' ').length
                                    });
                                    break;
                                }
                            }
                        }
                        let highestPercentage = -1;
                        let highestKeyWordLength = -1;
                        let indexOfMaxValue = 0;
                        if (filteredResults.length > 1) {
                            for (let i in filteredResults) {
                                // if percentage is same and length is less then keywords with lower length
                                // if percentage is 1 then length with bigger keyword is considered
                                if (filteredObject[i]['percentage'] > highestPercentage) {
                                    indexOfMaxValue = i;
                                    highestKeyWordLength = filteredObject[i]['keyWordLength'];
                                    highestPercentage = filteredObject[i]['percentage'];
                                } else if (filteredObject[i]['percentage'] === highestPercentage && highestPercentage === 1 && filteredObject[i]['keyWordLength'] > highestKeyWordLength) {
                                    highestKeyWordLength = filteredObject[i]['keyWordLength'];
                                    indexOfMaxValue = i;
                                } else if (filteredObject[i]['percentage'] === highestPercentage && filteredObject[i]['keyWordLength'] < highestKeyWordLength && highestPercentage !== 1) {
                                    highestKeyWordLength = filteredObject[i]['keyWordLength'];
                                    indexOfMaxValue = i;
                                }

                            }
                            let firstElement = filteredResults[0];
                            filteredResults[0] = filteredResults[indexOfMaxValue];
                            filteredResults[indexOfMaxValue] = firstElement;
                        }
                        resolve(filteredResults);
                    } else {
                        resolve([]);
                    }
                });
            } else {
                resolve([]);
            }
        });
    };
    this.set = function (key, data, expiry) {
        return memoryInstance.set(key, data, expiry);
    };

    this["delete"] = function (key) {
        return memoryInstance.delete(key);
    };

    this["get"] = function (key) {
        return memoryInstance.get(key);
    };

    this.getAllBots = function () {
        return app.datastore.find({
            table: "orchestrator",
            query: {},
            limit: mapping.childBots ? mapping.childBots.length : 10
        });
    };

    this.context = {};
    this.getContext = function () {
        return new Promise(function (resolve) {
            app.memory.get("orchestrator").then(function (context) {
                self.context = JSON.parse(context);
                resolve();
            }, function () {
                resolve();
            });
        });
    };


    this.saveContext = function () {
        return app.memory.set("orchestrator", self.context);
    };

    this.clearContext = function () {
        self.context = {};
        return app.memory.set("orchestrator", self.context);
    };


    this.start = function (options) {
        if (options) {
            self.options = _.assign(self.options, options);
        }
        app.orchestratorStarted = true;
        self.getBots(app.data.message, self.options.searchedFilterConfidence)
            .then(function (bots) {
                self.bots = bots;
                return self.getContext();
            })
            .then(function () {
                if (self.bots.length > 0 && self.context.current !== self.bots[0].botId) {
                    self.clearChildBotsContext(self.context.current).then(() => {
                        self.context.searchedBots = self.bots;
                        self.context.current = self.bots[0].botId;
                        self.startBot(self.context.current);
                        self.saveContext();
                    });

                } else {
                    if (self.context.current && !app.referrer) {
                        // deleting the searched bots if it exists
                        if (self.bots.length > 0) {
                            // assigning to bots if search bots doesnt exist
                            self.context.searchedBots = self.bots;
                            self.saveContext();
                        } else if (self.context.searchedBots) {
                            delete self.context.searchedBots;
                            self.saveContext();
                        }
                        self.startBot(self.context.current);
                    } else {
                        let searchOtherChildBots = (childBots) => {
                            app.ai.predictMultiple(app.data.message, _.map(childBots, function (bot) {
                                return bot.botId;
                            }))
                                .then(function (results) {
                                    let predictions = _.map(results, function (result, idx) {
                                        return {bot: childBots[idx], prediction: result.value};
                                    });

                                    let filtered = _.filter(predictions, function (prediction) {
                                        let askConfidence = self.options.askConfidenceByBots[prediction.bot.botName] ? self.options.askConfidenceByBots[prediction.bot.botName] : self.options.askConfidence;
                                        return prediction.prediction.confidence > askConfidence && prediction.prediction.intent.indexOf("global_") !== 0;
                                    });

                                    if (filtered.length > 1) {
                                        self.context.message = app.data.message;
                                        delete self.context.searchedBots;
                                        // saving the options as well to verify it in start bot
                                        self.context.productOptions = _.map(filtered, function (bot) {
                                            return bot.bot.botName.toLowerCase();
                                        });
                                        self.saveContext();
                                        app.sendQuickReplies({
                                            title: "Please select a product",
                                            options: _.map(filtered, function (bot) {
                                                return {
                                                    title: bot.bot.botName,
                                                    text: bot.bot.botName
                                                }
                                            })
                                        });
                                    } else if (filtered.length > 0 && (!app.referrer || app.referrer !== filtered[0].bot.botId)) {
                                        delete self.context.searchedBots;
                                        self.context.current = filtered[0].bot.botId;
                                        self.startBot(self.context.current);
                                        self.saveContext();
                                    } else {
                                        // delete the searched bots if its getting stuck

                                        if (self.context.searchedBots) {
                                            delete self.context.searchedBots;
                                            self.saveContext();
                                        }
                                        app.start({minConfidence: self.options.minConfidence});
                                    }
                                });
                        };
                        /* if length is more than 1 then predict all is called for all  searched bots
                         if length is 1 then app.start is done for orchestrator
                         if length is 0 then predict multiple is done for all bots
                        */
                        if (app.data.message && self.context.message && self.context.productOptions && self.context.productOptions.indexOf(app.data.message.toLowerCase()) !== -1){
                            // if productoptions is there and it matches with message then directly that particular bot is triggered
                            self.getAllBots().then(function (allBots) {
                                delete self.context.searchedBots;
                                self.context.current = _.find(allBots, (bot) => {
                                    return bot.botName.toLowerCase() === app.data.message.toLowerCase();
                                }).botId;
                                self.startBot(self.context.current);
                                self.saveContext();
                            });
                        }
                        else if (self.context && self.context.searchedBots && self.context.searchedBots.length > 1) {
                            // searching through other searched child bots
                            searchOtherChildBots(self.context.searchedBots.slice(1));
                        } else if (self.context && self.context.searchedBots && self.context.searchedBots.length === 1) {
                            app.start({minConfidence: self.options.minConfidence});
                        } else {
                            self.getAllBots().then(function (allBots) {
                                // all secondary child bots are ignored while asking all child bots
                                searchOtherChildBots(_.filter(allBots, (bot) => {
                                    return self.options.secondaryChildBots.indexOf(bot.botName) === -1;
                                }));
                            });
                        }
                    }
                }
            });
    };

    this.startBot = function (bot) {
        if (app.data.message && self.context.message && self.context.productOptions && self.context.productOptions.indexOf(app.data.message.toLowerCase()) !== -1) {
            //a param is passed if orchestrator is true
            app.ask(bot, {message: self.context.message});
            delete self.context.message;
            delete self.context.productOptions;
            self.saveContext();
        } else {
            if (self.context.productOptions) {
                delete self.context.message;
                delete self.context.productOptions;
                self.saveContext();
            }
            app.ask(bot);
        }
    };

    this.setBot = function (bot) {
        self.context.current = bot;
        return self.saveContext();
    };
};

module.exports = {
    Orchestrator
};
