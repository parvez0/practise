const numberDict = {
    zero: '0',
    one: '1',
    two: '2',
    three: '3',
    four: '4',
    five: '5',
    six: '6',
    seven: '7',
    eight: '8',
    nine: '9',
    ten: '10',
    eleven: '11',
    twelve: '12',
    thirteen: '13',
    fourteen: '14',
    fifteen: '15',
    sixteen: '16',
    seventeen: '17',
    eighteen: '18',
    nineteen: '19',
    twenty: '20',
    thirty: '30',
    forty: '40',
    fifty: '50',
    sixty: '60',
    seventy: '70',
    eighty: '80',
    ninety: '90',
    "0":'0',
    "1":'1',
    "2":'2',
    "3":'3',
    "4":'4',
    "5":'5',
    "6":'6',
    "7":'7',
    "8":'8',
    "9":'9',
    "10":'10'

};

function getNumber(message) {
    //handling error
    if (!message || message == "") {
        return "Message is empty";
    }
    //finding the first occurence of double triple or numbers
    message = message.toLowerCase();
    message=message.trim()
    let wordList = message.split(' ');
    let number = "";
    let double=/double|doubel/gi
    let triple=/triple/gi
    for(let i = 0;i<wordList.length;i++) {
        if(double.exec(wordList[i])) {
            try{
                if (numberDict.hasOwnProperty(wordList[i+1])){
                    number+=numberDict[wordList[i+1]]+numberDict[wordList[i+1]];
                    i+=1;
                }


            }
            catch(err){

            }

        } else if (triple.exec(wordList[i])) {
            try{
                if (numberDict.hasOwnProperty(wordList[i+1])){
                    number+=numberDict[wordList[i+1]]+numberDict[wordList[i+1]]+numberDict[wordList[i+1]];
                    i+=1;
                }



            }
            catch(err){
            }

        } else {
            try{
                if (numberDict.hasOwnProperty(wordList[i])){
                    number+=numberDict[wordList[i]]                }


            }
            catch(err){
            }
        }
    }
    return number;

}


module.exports = {
    getNumber
};