'use strict';
const request = require('request');

let call = function(method, data){
    return new Promise((resolve) => {
        request({
            url: "http://10.4.0.26:3000/rpc-internal/"+method,
            method: "POST",
            json: data,
        }, (err, resp, body) => {
            resolve(body)
        });
    })
};

module.exports = {
    call
};
