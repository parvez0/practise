/**
 * Created by sachin on 27 Apr 2018.
 */

const metrics = require('metrics-druid');
let Analytics = function (sender, bot, source, profile, data) {
    this.increment = function (event, tags, value) {
        try {
            if (!event) {
                return;
            }

            if (!tags) {
                tags = {};
            }

            tags.user = bot;
            tags.bot = bot;
            tags.source = source;
            tags.uid = sender;
            tags.event = event;

            if (profile) {
                for (let key in profile) {
                    if (profile.hasOwnProperty(key)) {
                        if (typeof(profile[key]) === "string") {
                            tags[`profile_${key}`] = profile[key];
                        }
                        else if (typeof(profile[key]) === "object") {
                            for (let nestedkey in profile[key]) {
                                if (profile[key].hasOwnProperty(nestedkey)) {
                                    tags[`profile_${nestedkey}`] = profile[key][nestedkey];

                                }
                            }
                        }
                    }
                }
            }

            if (data) {
                for (let key in data) {
                    if (data.hasOwnProperty(key)) {
                        if (typeof(data[key]) === "string") {
                            tags[key] = data[key];
                        }
                    }
                }
            }


            metrics.increment("events.bots.custom", tags, value);

            // list of finserv bots hardcoded for now
            const FINSERV_BOTS = ['bot_1494260176641'];
            if (FINSERV_BOTS.indexOf(bot) !== -1) {
                tags.id = uuid();
                cosmos.createDocument('vault', 'metrics', tags);
            }
        } catch (e) {
            // console.log(e);
        }

    };

    this.incrementInternal = function (event, tags, value) {
        try {
            if (!event) {
                return;
            }

            if (!tags) {
                tags = {};
            }

            tags.user = bot;
            tags.bot = bot;
            tags.source = source;
            tags.uid = sender;
            tags.event = event;

            if (profile) {
                for (let key in profile) {
                    if (profile.hasOwnProperty(key)) {
                        if (typeof(profile[key]) === "string") {
                            tags[`profile_${key}`] = profile[key];
                        }
                        else if (typeof(profile[key]) === "object") {
                            for (let nestedkey in profile[key]) {
                                if (profile[key].hasOwnProperty(nestedkey)) {
                                    tags[`profile_${nestedkey}`] = profile[key][nestedkey];

                                }
                            }
                        }
                    }
                }
            }

            if (data) {
                for (let key in data) {
                    if (data.hasOwnProperty(key)) {
                        if (typeof(data[key]) === "string") {
                            tags[key] = data[key];
                        }
                    }
                }
            }

            metrics.increment("events.bots", tags, value);

            // list of finserv bots hardcoded for now
            const FINSERV_BOTS = ['bot_1494260176641'];
            if (FINSERV_BOTS.indexOf(bot) !== -1) {
                tags.id = uuid();
                cosmos.createDocument('vault', 'metrics', tags);
            }
        } catch (e) {
            // console.log(e);
        }
    };
};

module.exports = {
    Analytics
};
