'use strict';

const config = require('../config');
const axios = require('axios')
const axiosInstance = axios.create({
    baseURL: config.urls.AI_BACKEND_SERVICE
});


module.exports = {
    getJourney: function (intent, bot) {
        return axiosInstance.get(`/journey/internal/get/${intent}?bot=${bot}`).then((response) => {
            return response.data.data.data;
        })
    },
    getStep: function (intent, slug) {
        return axiosInstance.get(`/step/internal/get/${slug}/${intent}`).then((response) => {
            return response.data.data.data;
        })
    },
    getMultipleJourneysBySlug: function (journeySlugs, bot) {
        return axiosInstance.post(`/journey/internal/getmultiple/?bot=${bot}`, {journeySlugs}).then((response) => {
            return response.data.data.data;
        })
    },

};

