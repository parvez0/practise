'use strict';

const axios = require('axios');
const config = require('../config');
const baseURL = config.urls.DATA_SERVICE;
const axiosInstance = axios.create({
    baseURL
});

const axiosDataWrapper = (data, serviceName) => {
    return axiosInstance({
        method: 'post',
        url: `/internal/redis/${serviceName}`,
        data
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    });
};

// Temporary storage
let Memory = function (bot, sender) {
    let prefix = "vstore_" + bot + "_" + sender + "_";
    let self = this;

    this.set = function (key, data, expiry) {
        data = {
            key: prefix + key,
            data: typeof data === "object" ? JSON.stringify(data) : data + '',
            expiry
        };
        return axiosDataWrapper(data,'set');
    };

    this.delete = function (key) {
        let data = {key: prefix + key};
        return axiosDataWrapper(data, 'del');
    };

    this.del = this.delete;

    this.get = function (key) {
        let data = {key: prefix + key};
        return axiosDataWrapper(data,'get');
    };


    this.hmset = function (key, dataKey, dataValue) {
        return self.get(key).then(function (data) {
            let dataObj = JSON.parse(data);
            dataObj[dataKey] = dataValue;
            return self.set(key, JSON.stringify(dataObj));
        }, function () {
            return self.set(key, JSON.stringify({
                dataKey: dataValue
            }));
        });
    };

    this.hdel = function (key, dataKey) {
        return self.get(key).then(function (data) {
            let dataObj = JSON.parse(data);
            delete dataObj[dataKey];
            return self.set(key, JSON.stringify(dataObj));
        });
    };

    this.getMultiple = function (keys) {
        return new Promise(function (resolve) {
            let arrFunc = _.map(keys, function (key) {
                return self.get(key);
            });

            Q.allSettled(arrFunc).then(function (results) {
                resolve(_.mapValues(_.keyBy(_.map(results, function (result, index) {
                    return {
                        key: keys[index],
                        value: result.state === "fulfilled" ? result.value : undefined
                    }
                }), 'key'), 'value'));
            });
        });
    };

};

//to access other context
function getContextOfOtherUser(bot, sender) {

    let prefix = "vstore_" + bot + "_" + sender + "_";
    let key = 'context';
    let data = {key: prefix + key};
    return axiosDataWrapper(data, 'get').then(function (contextString) {
        contextString = JSON.parse(contextString);
        resolve(contextString);
    }, function () {
        resolve({});
    });
};

module.exports = {
    Memory,
    getContextOfOtherUser,
    set: function (key, data, expiry) {
        data = {
            key,
            data: typeof data === "object" ? JSON.stringify(data) : data + '',
            expiry
        };
        return axiosDataWrapper(data, 'set');
    }
};
