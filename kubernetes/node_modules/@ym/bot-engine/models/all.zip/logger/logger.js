/**
 * Created by sachin on 27 Apr 2018.
 */

const rabbit = require('../rabbit');

let Logger = function (bot, sender, source) {
    this.log = function (data, tag) {
        rabbit.publish(JSON.stringify({
                sender: sender,
                data: data instanceof Error ? data.message : data,
                source: source,
                bot: bot,
                tag: tag
            }),'logger-queue',
            function (published) {
                // console.log("Published event");
            });
    }
};

module.exports = {
    Logger
};
