/**
 * Created by sachin on 27 Apr 2018.
 */

const phonetics = require('soundex-phonetics')
const getPhonetics = (sentence) => {
    return new Promise((resolve) => {
        // tokenizing the sentence by space
        let wordList = sentence.split(" ");
        let phoneticsList = []
        wordList.forEach((element) => {
            phoneticsList.push(phonetics['soundex-phonetics'](element))
        })
        return resolve(phoneticsList.join(' '));
    })

}

module.exports = {
    getPhonetics

};
