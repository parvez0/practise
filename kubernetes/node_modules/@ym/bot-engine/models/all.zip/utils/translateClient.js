const request = require('request').defaults({pool: {maxSockets: 25}});

const translate = (message, language, callback) => {
    let sourceLanguage;
    let targetLanguage;
    if (typeof language === 'object') {
        targetLanguage = language.to;
        sourceLanguage = language.from;
    } else {
        sourceLanguage = 'en';
        targetLanguage = language;
    }
    let option = {
        method: 'POST',
        url: 'https://translation.googleapis.com/language/translate/v2',
        qs: {key: 'AIzaSyC58K6j7u5BHeQZOYEb6xEpZuhDZ12KtwY'},
        headers:
            {
                'postman-token': '2d2ef621-4027-c3fd-e6d5-206c9566e387',
                'cache-control': 'no-cache',
                'content-type': 'application/json'
            },
        body:
            {
                q: message,
                source: sourceLanguage,
                target: targetLanguage,
                format: 'text'
            },
        json: true,
        timeout: 2000
    };
    request(option, function (error, response, body) {
        if (body && body.data && body.data.translations && body.data.translations.length > 0) {
            if (body.data.translations.length === 1) {
                if (callback) {
                    callback(error, body.data.translations[0].translatedText);
                }
            }
            else {
                let translations = [];
                body.data.translations.forEach((e) => {
                    translations.push(e.translatedText);
                });
                if (callback) {
                    callback(error, translations);
                }
            }

        }
        else {
            callback(error, message);
        }
    });
};
module.exports = {
    translate
};
