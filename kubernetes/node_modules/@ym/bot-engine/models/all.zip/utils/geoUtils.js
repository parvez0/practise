/**
 * Created by sachin on 27 Apr 2018.
 */

const GEO_CODE_BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json";
const GEO_CODE_KEY = "AIzaSyD9elXG6S4B-yKjN9IU_I7nOWAbuwoei4w";
const _ = require('lodash');
const request = require('request').defaults({agent: false, pool: {maxSockets: 10}});

let geoCode = function (address) {
    return new Promise(function (resolve, reject) {
        if (!address || !address.trim()) {
            return reject();
        }
        let qs = {
            address: address,
            key: GEO_CODE_KEY
        };
        request.get({
            url: GEO_CODE_BASE_URL,
            qs,
            json: true
        }, (err, response, body) => {
            if (!err && body) {
                if (body.results.length === 0) {
                    reject();
                } else {
                    resolve({
                        lat: body.results[0].geometry.location.lat,
                        lon: body.results[0].geometry.location.lng
                    });
                }
            } else {
                reject(err);
            }
        });
    });
};

let reverseGeoCode = function (location) {
    return new Promise((resolve, reject) => {
        let qs = {
            latlng: `${location.lat},${location.lon}`,
            result_type: 'locality|country',
            key: GEO_CODE_KEY
        };
        request.get({
            url: GEO_CODE_BASE_URL,
            qs: {
                latlng: `${location.lat},${location.lon}`,
                key: GEO_CODE_KEY
            },
            json: true
        }, (err, response, geoCodeBody) => {
            if (!err) {
                if (geoCodeBody.results.length > 0) {
                    let addresses = geoCodeBody.results[0].address_components;
                    let address = {
                        country: _.chain(addresses).filter((address) => {
                            return address.types.indexOf('country') !== -1;
                        }).take(1).value()[0]['long_name'],
                        code: _.chain(addresses).filter((address) => {
                            return address.types.indexOf('country') !== -1;
                        }).take(1).value()[0]['short_name'],
                        locality: _.chain(addresses).filter((address) => {
                            return address.types.indexOf('locality') !== -1;
                        }).take(1).value()
                    };
                    resolve(address);
                } else {
                    reject();
                }
            } else {
                reject(err);
            }
        })
    });
};
module.exports = {
    geoCode,
    reverseGeoCode
}
