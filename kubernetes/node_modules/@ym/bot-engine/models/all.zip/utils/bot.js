/**
 * Created by sachin on 27 Apr 2018.
 */
'use strict';
const axios = require('axios');
const config = require('../../config');
const baseURL = config.urls.DATA_SERVICE;
const axiosInstance = axios.create({
    baseURL
});

const axiosDataWrapper = (data, serviceName) => {
    return axiosInstance({
        method: 'post',
        url: `/internal/redis/${serviceName}`,
        data
    }).then((response) => {
        response = response.data;
        if (response.success) {
            return response.data;
        } else {
            return Promise.reject(new Error(response.data));
        }
    });
};
let pauseBot = (bot,sender,source,expiry) => {
    let redisPauseKey = `${bot}:${source}:${sender}:paused`;
    let data = {
        key: redisPauseKey,
        data: JSON.stringify({"paused": true}),
        expiry:expiry?expiry:900
    };
    return axiosDataWrapper(data,'set');
};

let unPauseBot = (bot,sender,source) => {
    let redisPauseKey = `${bot}:${source}:${sender}:paused`;
    let data = {key: redisPauseKey};
    return axiosDataWrapper(data, 'del');
};

let isBotPaused = (bot,sender,source) => {
    let redisPauseKey = `${bot}:${source}:${sender}:paused`;
    let data = {key: redisPauseKey};
    return axiosDataWrapper(data,'get');
};

module.exports = {
    isBotPaused,
    unPauseBot,
    pauseBot
};
