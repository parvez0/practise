
/**
 * Created by sachin on 27 Apr 2018.
 */
const request = require('request');

let machineComprehension = (passage,question) =>{
    return new Promise((resolve,reject)=>{
        let options={
            method: 'POST',
            url: 'http://10.4.0.32:9000/predict/machine-comprehension',
            headers: {
                'cache-control': 'no-cache',
                'content-type': 'application/json'
            },
            body:{
                passage:passage ,
                question: question
            },
            json: true,
            timeout: 2000
        };
        request(options,function (error,response,body) {
            if (error){
                reject(error);
            }
            else{
                if (body.best_span_str) {
                    resolve(body.best_span_str);
                } else {
                    reject();
                }
            }
        })

    });
};

module.exports = {
    machineComprehension
}
