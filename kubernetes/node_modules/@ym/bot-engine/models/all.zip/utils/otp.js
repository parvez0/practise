/**
 * Created by sachin on 27 Apr 2018.
 */

const request = require('request');

let sendOtp = function (number,set) {
    return new Promise(function (resolve, reject) {
        let ran4 = Math.floor(Math.random() * 8999 + 1000);
        let authkey = "187279AroFr1Ml1mhN5a2a516e";
        number = number.trim();
        let sender = "YLWMSR";
        let options = {
            method: 'GET',
            url: 'http://control.msg91.com/api/sendotp.php',
            qs: {
                'authkey': authkey,
                'mobile': number,
                'sender': sender,
                'message': "Your verification code is " + ran4,
                'otp': ran4
            },
            headers: {
                'cache-control': 'no-cache',
                'content-type': 'application/json',
            },
            json: true
        };

        request(options, function (error, response, dataBody) {
            if (error || dataBody['type'] === "error") {
                reject(error);
            } else {
                set("otp", ran4, 60 * 5);
                resolve(ran4);
            }
        });
    });
};

let verifyOtp = function (otp,get) {
    return new Promise(function (resolve, reject) {
        get("otp").then(function (val) {
            if (otp.toString().trim() === val.toString()) {
                resolve({'success': true})
            }
            else {
                resolve({'success': false})
            }
        }, function (err) {
            resolve({'success': false})
        });
    });
};

module.exports = {
    verifyOtp,
    sendOtp
}
