'use strict';
const
    crypto = require("crypto"),
    request = require("request");

const TOKEN  = "NzoMojbo03FVmXkiOL1hIbWMSa8doBn1E0IDXcA4zHTbJhwv3aErBmdUHXK8OAr7mSVLj7NbD3Q2WRSMZiJ7Nw==";
function getAuthorizationTokenUsingMasterKey(verb, resourceType, resourceId, date, masterKey) {
    const key = new Buffer(masterKey, "base64");
    const text = (verb || "").toLowerCase() + "\n" +
        (resourceType || "").toLowerCase() + "\n" +
        (resourceId || "") + "\n" +
        date.toLowerCase() + "\n" +
        "" + "\n";
    const body = new Buffer(text, "utf8");
    const signature = crypto.createHmac("sha256", key).update(body).digest("base64");
    const MasterToken = "master";
    const TokenVersion = "1.0";
    return encodeURIComponent("type=" + MasterToken + "&ver=" + TokenVersion + "&sig=" + signature);
}

function createDocument(dbName, collectionName,doc){
    const utc = new Date();

    const options = { method: 'POST',
        url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls/'+collectionName+'/docs',
        headers:
            {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'x-ms-version': '2014-08-21',
                'x-ms-date': utc.toUTCString(),
                Authorization: getAuthorizationTokenUsingMasterKey("POST","docs",'dbs/'+dbName+'/colls/'+collectionName,utc.toUTCString(),TOKEN)
            },
        body: doc,
        json: true,
        timeout: 2000
    };

    request(options, function (error, response, body) {
        if(error){
            console.log("cosmos error: ");
            console.log(error);
        }
    });
}


function listDocuments(dbName, collectionName){
    return new Promise(function(resolve, reject){
        const utc = new Date();

        const options = { method: 'GET',
            url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls/'+collectionName+'/docs',
            headers:
                {
                    'Cache-Control': 'no-cache',
                    'Content-Type': 'application/json',
                    'x-ms-version': '2014-08-21',
                    'x-ms-date': utc.toUTCString(),
                    Authorization: getAuthorizationTokenUsingMasterKey("GET","docs",'dbs/'+dbName+'/colls/'+collectionName,utc.toUTCString(),TOKEN)
                },
            json: true,
            timeout: 2000
        };

        request(options, function (error, response, body) {
            if(error){
                reject(error);
            }else{
                resolve(body);
            }
        });
    });
}

function listCollections(dbName){
    const utc = new Date();
    const options = { method: 'GET',
        url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls',
        headers:
            {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'x-ms-version': '2014-08-21',
                'x-ms-date': utc.toUTCString(),
                Authorization: getAuthorizationTokenUsingMasterKey("GET","colls",'dbs/'+dbName,utc.toUTCString(),TOKEN)
            },
        json: true };

    request(options, function (error, response, body) {
        if (error) throw new Error(error);

    });
}

function createDatabase(dbName){
    const utc = new Date();
    const options = { method: 'POST',
        url: 'https://chatbot.documents.azure.com/dbs',
        headers:
            {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'x-ms-version': '2014-08-21',
                'x-ms-date': utc.toUTCString(),
                Authorization: getAuthorizationTokenUsingMasterKey("POST","dbs","",utc.toUTCString(),TOKEN)
            },
        body: {
            id: dbName
        },
        json: true };

    request(options, function (error, response, body) {
        if (error) throw new Error(error);

    });
}

function createCollection(dbName, collectionName){
    const utc = new Date();
    const options = { method: 'POST',
        url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls',
        headers:
            {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'x-ms-version': '2014-08-21',
                'x-ms-date': utc.toUTCString(),
                Authorization: getAuthorizationTokenUsingMasterKey("POST","colls",'dbs/'+dbName,utc.toUTCString(),TOKEN)
            },
        body: {
            "id": collectionName,
            "indexingPolicy": {
                "automatic": true,
                "indexingMode": "Consistent",
                "includedPaths": [
                    {
                        "path": "/*",
                        "indexes": [
                            {
                                "dataType": "String",
                                "precision": -1,
                                "kind": "Range"
                            },
                            {
                                "kind": "Range",
                                "dataType": "Number",
                                "precision": -1
                            }
                        ]
                    }
                ]
            }
        } ,
        json: true };

    request(options, function (error, response, body) {
        if (error) throw new Error(error);
    });
}

function updateCollectionIndices(dbName, collectionName){
    const utc = new Date();
    const options = { method: 'PUT',
        url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls/'+collectionName,
        headers:
            {
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json',
                'x-ms-version': '2015-06-03',
                'x-ms-date': utc.toUTCString(),
                Authorization: getAuthorizationTokenUsingMasterKey("PUT","colls",'dbs/'+dbName+"/colls/"+collectionName,utc.toUTCString(),TOKEN)
            },
        body: {
            "id": collectionName,
            "indexingPolicy": {
                "automatic": true,
                "indexingMode": "Lazy",
                "includedPaths": [
                    {
                        "path": "/*",
                        "indexes": [
                            {
                                "dataType": "String",
                                "precision": -1,
                                "kind": "Range"
                            },
                            {
                                "kind": "Range",
                                "dataType": "Number",
                                "precision": -1
                            }
                        ]
                    }
                ]
            }
        } ,
        json: true };

    request(options, function (error, response, body) {
        if (error) throw new Error(error);

    });
}

function queryDocuments(dbName, collectionName, query, parameters){
    return new Promise(function(resolve, reject){
        const utc = new Date();
        const options = { method: 'POST',
            url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls/'+collectionName+'/docs',
            headers:
                {
                    'Cache-Control': 'no-cache',
                    'Content-Type': 'application/query+json',
                    'x-ms-version': '2014-08-21',
                    'x-ms-documentdb-isquery': 'True',
                    'x-ms-date': utc.toUTCString(),
                    Authorization: getAuthorizationTokenUsingMasterKey("POST","docs",'dbs/'+dbName+'/colls/'+collectionName,utc.toUTCString(),TOKEN)
                },
            body: {
                query: query,
                parameters: parameters
            },
            json: true,
            timeout: 2000
        };

        request(options, function (error, response, body) {
            if(error){
                reject(error);
            }else{
                resolve(body);
            }
        });
    });
}

function getDocument(dbName, collectionName, id){
    return new Promise(function(resolve, reject){
        const utc = new Date();
        const options = { method: 'GET',
            url: 'https://chatbot.documents.azure.com/dbs/'+dbName+'/colls/'+collectionName+'/docs/'+id,
            headers:
                {
                    'Cache-Control': 'no-cache',
                    'Content-Type': 'application/json',
                    'x-ms-version': '2014-08-21',
                    'x-ms-date': utc.toUTCString(),
                    Authorization: getAuthorizationTokenUsingMasterKey("GET","docs",'dbs/'+dbName+'/colls/'+collectionName+'/docs/'+id,utc.toUTCString(),TOKEN)
                },
            json: true,
            timeout: 2000
        };

        request(options, function (error, response, body) {
            if(error){
                reject(error);
            }else{
                resolve(body);
            }
        });
    });
}

module.exports = {
    createDocument,
    listDocuments,
    queryDocuments,
    getDocument,
    updateCollectionIndices
};
