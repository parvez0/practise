'use strict';
const rpcClient = require('./rpcClient');

module.exports = {
    sendMessage: function(sender, email, bot){
        rpcClient.call("emailSender/sendMessage", {
            sender: sender, data: email, from: bot
        });
    }
};